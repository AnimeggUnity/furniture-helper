<?php
// =================================================================
// LINE Bot Webhook - 簡化測試版本
// 整合 GD 圖片優化器
// =================================================================

// 類別對照表
define('CATEGORY_MAPPING', [
    '茶几' => 6,
    '沙發' => 39,
    '收納櫃' => 9,
    '鞋架' => 10,
    '鞋櫃' => 10,
    '玄關櫃' => 11,
    '電視櫃' => 12,
    '椅子' => 40,
    '書櫃' => 14,
    '書桌' => 15,
    '家飾' => 28,
    '燈具' => 29,
    '燈飾' => 29,
    '家用電器' => 30,
    '腳踏車' => 31,
    '其他' => 32
]);

// 預設類別ID
define('DEFAULT_CATEGORY_ID', 32);

// 檢查設定檔是否存在，如果不存在則導向設定精靈
if (!file_exists(__DIR__ . '/config.php')) {
    header('Location: setup_wizard.php');
    exit;
}

// 載入設定
require_once 'config.php';

// 設定時區
date_default_timezone_set('Asia/Taipei');

// 啟用錯誤記錄
error_reporting(E_ALL);
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/webhook_errors.log');





/**
 * 簡化的日誌記錄函數（不依賴資料庫）
 */
function logMessage($level, $message, $context = []) {
    $timestamp = date('Y-m-d H:i:s');
    $context_str = !empty($context) ? ' | ' . json_encode($context, JSON_UNESCAPED_UNICODE) : '';
    $log_entry = "[{$timestamp}] [{$level}] {$message}{$context_str}\n";
    
    $log_file = __DIR__ . '/webhook.log';
    file_put_contents($log_file, $log_entry, FILE_APPEND | LOCK_EX);
}



/**
 * 記錄請求開始
 */
function logRequestStart() {
    $GLOBALS['system_start_time'] = microtime(true);
    
    logMessage('DEBUG', '請求開始', [
        'method' => $_SERVER['REQUEST_METHOD'] ?? 'unknown',
        'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? 'unknown'
    ]);
}

/**
 * 記錄請求結束
 */
function logRequestEnd() {
    if (isset($GLOBALS['system_start_time'])) {
        $execution_time = microtime(true) - $GLOBALS['system_start_time'];
        logMessage('DEBUG', '請求結束', [
            'execution_time' => round($execution_time * 1000, 2) . 'ms'
        ]);
    }
}

// 記錄請求開始
logRequestStart();



try {
    // 取得 LINE 請求內容
    $input = file_get_contents('php://input');
    
    if (empty($input)) {
        logMessage('ERROR', '請求內容為空');
        http_response_code(400);
        echo json_encode(['error' => '請求內容為空']);
        exit;
    }
    
    $events = json_decode($input, true);
    
    if (json_last_error() !== JSON_ERROR_NONE) {
        logMessage('ERROR', 'JSON 解析失敗', [
            'json_error' => json_last_error_msg(),
            'input' => substr($input, 0, 200)
        ]);
        http_response_code(400);
        echo json_encode(['error' => '無效的 JSON 格式']);
        exit;
    }
    
    if (!$events || !isset($events['events'])) {
        logMessage('ERROR', '無效的 LINE 請求格式', ['input' => substr($input, 0, 200)]);
        http_response_code(400);
        echo json_encode(['error' => '無效的 LINE 請求格式']);
        exit;
    }
    
    // 處理空事件陣列（LINE 的 keep-alive 或測試請求）
    if (empty($events['events'])) {
        logMessage('INFO', '收到空事件陣列（可能是 keep-alive 請求）');
        http_response_code(200);
        echo 'OK';
        exit;
    }
    
    // 驗證 LINE 簽名（如果啟用）
    if (defined('LINE_CHANNEL_SECRET') && LINE_CHANNEL_SECRET) {
        $signature = $_SERVER['HTTP_X_LINE_SIGNATURE'] ?? '';
        if (!verifyLineSignature($input, $signature)) {
            logMessage('ERROR', 'LINE 簽名驗證失敗');
            http_response_code(403);
            exit;
        }
    }
    
    // 處理每個事件
    foreach ($events['events'] as $event) {
        if ($event['type'] !== 'message') continue;
        
        $userId = $event['source']['userId'];
        $message = $event['message'];
        $replyToken = $event['replyToken'];
        
        logMessage('INFO', '收到訊息', [
            'user_id' => $userId,
            'message_type' => $message['type']
        ]);
        
        // 載入使用者狀態
        $userStateFile = __DIR__ . "/user_states/{$userId}.json";
        $userState = loadUserState($userId);
        
        // 處理文字訊息
        if ($message['type'] === 'text') {
            $text = trim($message['text']);
            
            switch ($text) {
                case '開始':
                    $userState = [
                        'status' => 'collecting_images',
                        'images' => [],
                        'start_time' => time()
                    ];
                    saveUserState($userId, $userState);
                    
                    replyLineMessage($replyToken, 
                        "🎯 開始收集家具圖片！\n\n" .
                        "請上傳家具圖片，我會幫您分析並生成產品資訊。\n" .
                        "上傳完成後，輸入「完成」來打包資料。\n\n" .
                        "📝 設定範例：\n" .
                        "• 標題 LED氣氛蠟燭 價格 800 內容 五個一組\n" .
                        "• 類別 茶几 標題 原木茶几 價格 1200\n" .
                        "• 標題 低跨點通勤腳踏車 價格 800 類別 腳踏車\n\n" .
                        "📋 可用指令：\n" .
                        "• 狀態 - 查看目前進度\n" .
                        "• 類別表 - 查看類別對照表\n" .
                        "• 測試 - 測試系統連線\n" .
                        "• 取消 - 重新開始\n" .
                        "• 完成 - 打包資料"
                    );
                    break;
                    
                case '狀態':
                    // 重新載入最新的使用者狀態
                    $userState = loadUserState($userId);
                    
                    // 檢查檔案是否存在
                    $userStateFile = __DIR__ . "/user_states/{$userId}.json";
                    $fileExists = file_exists($userStateFile);
                    $fileSize = $fileExists ? filesize($userStateFile) : 0;
                    
                    // 記錄除錯資訊
                    logMessage('INFO', '狀態查詢', [
                        'user_id' => $userId,
                        'status' => $userState['status'] ?? '未開始',
                        'image_count' => count($userState['images'] ?? []),
                        'has_images' => !empty($userState['images']),
                        'user_state_file' => $userStateFile,
                        'file_exists' => $fileExists,
                        'file_size' => $fileSize
                    ]);
                    
                    $statusText = "📊 目前狀態：\n";
                    $statusText .= "• 狀態：" . ($userState['status'] ?? '未開始') . "\n";
                    $statusText .= "• 圖片數量：" . count($userState['images'] ?? []) . " 張\n";
                    $statusText .= "• 類別：" . getCategoryName($userState['category_id'] ?? DEFAULT_CATEGORY_ID) . " (ID: " . ($userState['category_id'] ?? DEFAULT_CATEGORY_ID) . ")\n";
                    $statusText .= "• 狀態檔案：" . ($fileExists ? '存在' : '不存在') . " (" . $fileSize . " bytes)\n";
                    
                    // 除錯：顯示狀態檔案的內容
                    if ($fileExists && $fileSize > 0) {
                        $fileContent = file_get_contents($userStateFile);
                        $statusText .= "• 檔案內容：" . substr($fileContent, 0, 100) . "...\n";
                    }
                    
                    if (!empty($userState['images'])) {
                        $totalOriginalSize = 0;
                        $totalCompressedSize = 0;
                        $needsTitle = isset($userState['needs_title']) && $userState['needs_title'];
                        $needsPrice = isset($userState['needs_price']) && $userState['needs_price'];
                        
                        foreach ($userState['images'] as $index => $img) {
                            $totalOriginalSize += $img['file_size'];
                        }
                        
                        $statusText .= "• 原始總大小：" . number_format($totalOriginalSize / 1024, 1) . " KB\n";
                        $statusText .= "• 商品標題：" . ($needsTitle ? '⏳ 待設定' : '✅ 已設定') . "\n";
                        $statusText .= "• 商品價格：" . ($needsPrice ? '⏳ 待設定' : '✅ 已設定') . "\n\n";
                        
                        // 顯示商品資訊
                        $statusText .= "📦 商品資訊：\n";
                        $statusText .= "• 標題：" . ($userState['title'] ?? '未設定') . "\n";
                        $statusText .= "• 價格：" . ($userState['price'] ?? '未設定') . " 元\n\n";
                        
                        // 顯示圖片詳情
                        $statusText .= "📷 圖片詳情：\n";
                        foreach ($userState['images'] as $index => $img) {
                            $imageNum = $index + 1;
                            $originalKB = number_format($img['file_size'] / 1024, 1);
                            $statusText .= "• 圖片{$imageNum}：{$originalKB}KB\n";
                        }
                    }
                    
                    if (isset($userState['start_time'])) {
                        $duration = time() - $userState['start_time'];
                        $statusText .= "\n⏰ 開始時間：" . date('H:i:s', $userState['start_time']) . "\n";
                        $statusText .= "⏱️ 耗時：" . gmdate('H:i:s', $duration) . "\n";
                    }
                    
                    replyLineMessage($replyToken, $statusText);
                    break;
                    
                case '類別表':
                    logMessage('INFO', '使用者請求類別表', ['user_id' => $userId]);
                    $categoryTable = generateCategoryTable();
                    logMessage('INFO', '類別表生成完成', [
                        'user_id' => $userId,
                        'table_length' => strlen($categoryTable)
                    ]);
                    $result = replyLineMessage($replyToken, $categoryTable);
                    if (!$result) {
                        logMessage('ERROR', '類別表發送失敗', ['user_id' => $userId]);
                    }
                    break;
                    
                case '測試':
                    logMessage('INFO', '使用者請求測試', ['user_id' => $userId]);
                    $result = replyLineMessage($replyToken, "✅ 測試訊息 - 系統正常運作！");
                    if (!$result) {
                        logMessage('ERROR', '測試訊息發送失敗', ['user_id' => $userId]);
                    }
                    break;
                    
                case '取消':
                    // 清理使用者狀態檔案
                    if (file_exists($userStateFile)) {
                        unlink($userStateFile);
                    }
                    
                    // 清理使用者圖片檔案
                    $userImageDir = __DIR__ . "/user_images/{$userId}";
                    if (is_dir($userImageDir)) {
                        deleteDirectory($userImageDir);
                    }
                    
                    replyLineMessage($replyToken, 
                        "🔄 已重新開始！\n\n" .
                        "請輸入「開始」來開始新的收集流程。"
                    );
                    break;
                    
                
                    
                case '完成':
                    if (empty($userState['images'])) {
                        replyLineMessage($replyToken, "❌ 沒有圖片可以打包，請先上傳一些圖片。");
                        break;
                    }
                    
                    // 檢查是否已設定標題和價格
                    if (isset($userState['needs_title']) && $userState['needs_title']) {
                        replyLineMessage($replyToken, "❌ 請先設定商品標題。");
                        break;
                    }
                    
                    if (isset($userState['needs_price']) && $userState['needs_price']) {
                        replyLineMessage($replyToken, "❌ 請先設定商品價格。");
                        break;
                    }
                    
                    // 生成 JSON 檔案（只使用標題作為檔名，處理重複）
                    $title = $userState['title'] ?? 'furniture';
                    if (empty(trim($title))) {
                        $title = 'furniture';
                    }
                    $titleForFilename = preg_replace('/[^a-zA-Z0-9\u4e00-\u9fa5]/', '', $title);
                    if (empty($titleForFilename)) {
                        $titleForFilename = 'furniture';
                    }
                    $filename = "{$titleForFilename}.json";
                    $filepath = __DIR__ . "/packaged_data/{$filename}";
                    
                    // 如果檔案已存在，加上數字後綴
                    $counter = 1;
                    while (file_exists($filepath)) {
                        $filename = "{$titleForFilename}_{$counter}.json";
                        $filepath = __DIR__ . "/packaged_data/{$filename}";
                        $counter++;
                    }
                    
                    // 確保目錄存在
                    if (!is_dir(__DIR__ . '/packaged_data')) {
                        mkdir(__DIR__ . '/packaged_data', 0755, true);
                    }
                    
                    // 準備 JSON 資料 - 按照 API 格式
                    $jsonData = [
                        'CategoryID' => $userState['category_id'] ?? DEFAULT_CATEGORY_ID,
                        'Name' => $userState['title'] ?? "家具項目",
                        'Description' => ($userState['additional_description'] ?? '') . "
" . "一、經新店區清潔隊回收後，些許整理後之堪用傢具及裝飾品非新品，無保固卡、非新品，如照片。
二、網站拍賣，得標領取後一概不退貨換貨，欲參加競標拍賣者請自行斟酌需求再下標。
三、預約取貨時間：星期一二四五六；13:30~16:30；電話:(02)2214-2829，敬請取貨前一天事先約定時間，(避免承辦人不在)。
四、取貨地點：薏仁坑路自強巷2-3號 （https://goo.gl/maps/dkpErErsL74yd4vG7），新店清潔隊資源回收組門口藍色倉庫，請(依約定時間取貨)，(不接受臨時領貨)，一律自行取貨，無提供寄送服務.",
                        'InitPrice' => $userState['price'] ?? "1000",
                        'OriginPrice' => $userState['price'] ?? "1000",
                        'MinAddPrice' => 10,
                        'StartDate' => "2024-01-15T00:00:00.00",
                        'EndDate' => "2024-01-15T00:00:00.00",
                        'DistID' => "231",
                        'DeliveryAddress' => "薏仁坑路自強巷2-3號",
                        'Length' => "0",
                        'Width' => "0",
                        'Height' => "0",
                        'Photos' => []
                    ];
                    
                    foreach ($userState['images'] as $index => $imageInfo) {
                        // 讀取原始圖片檔案
                        $originalPath = __DIR__ . "/" . $imageInfo['original_file'];
                        if (file_exists($originalPath)) {
                            $imageData = file_get_contents($originalPath);
                            $base64Image = base64_encode($imageData);
                            
                            $jsonData['Photos'][] = [
                                'Photo' => "data:image/jpeg;base64," . $base64Image,
                                'PhotoID' => "img_" . str_pad($index + 1, 3, '0', STR_PAD_LEFT)
                            ];
                        }
                    }
                    
                    // 寫入 JSON 檔案
                    $jsonContent = json_encode($jsonData, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
                    file_put_contents($filepath, $jsonContent);
                    
                    // 生成下載連結
                    $downloadUrl = "https://" . $_SERVER['HTTP_HOST'] . dirname($_SERVER['REQUEST_URI']) . "/files.php";
                    
                    // 清理使用者狀態
                    if (file_exists($userStateFile)) {
                        unlink($userStateFile);
                    }

                    // 清理使用者圖片檔案
                    $userImageDir = __DIR__ . "/user_images/{$userId}";
                    if (is_dir($userImageDir)) {
                        deleteDirectory($userImageDir);
                    }
                    
                    $totalSize = strlen($jsonContent);
                    $totalImages = count($userState['images']);
                    
                    replyLineMessage($replyToken, 
                        "🎉 資料打包完成！\n\n" .
                        "📁 檔案資訊：\n" .
                        "• 檔名：{$filename}\n" .
                        "• 大小：" . number_format($totalSize / 1024, 1) . " KB\n" .
                        "• 圖片數量：{$totalImages} 張\n\n" .
                        "📥 下載連結：\n" .
                        "{$downloadUrl}\n\n" .
                        "💡 點擊連結查看最新檔案並下載！"
                    );
                    break;
                    
                default:
                    // 使用正規表達式解析更靈活的輸入格式
                    $title = null;
                    $price = null;
                    $category = null;
                    
                    // 嘗試解析類別
                    $category = parseCategory($text);
                    logMessage('DEBUG', '類別解析結果', [
                        'user_id' => $userId,
                        'input_text' => $text,
                        'parsed_category' => $category,
                        'category_name' => $category ? getCategoryName($category) : 'null'
                    ]);
                    
                    // 嘗試解析標題
                    if (preg_match('/標題\s*[：:]\s*(.+?)(?=\s+價格|$)/', $text, $matches)) {
                        $title = trim($matches[1]);
                    } elseif (preg_match('/標題\s+(.+?)(?=\s+價格|$)/', $text, $matches)) {
                        $title = trim($matches[1]);
                    }
                    
                    // 嘗試解析價格
                    if (preg_match('/價格\s*[：:]\s*(\d+)/', $text, $matches)) {
                        $price = $matches[1];
                    } elseif (preg_match('/價格\s+(\d+)/', $text, $matches)) {
                        $price = $matches[1];
                    }

                    // 嘗試解析附加資訊
                    $additional_description = null;
                    if (preg_match('/內容\s*[：:]\s*(.+)/s', $text, $matches)) {
                        $additional_description = trim($matches[1]);
                    } elseif (preg_match('/內容\s+(.+)/s', $text, $matches)) {
                        $additional_description = trim($matches[1]);
                    }
                    
                    // 處理解析結果
                    if ($title || $price || $category || $additional_description) {
                        if (!empty($userState['images'])) {
                            $updated = false;
                            $response = "✅ 設定更新：\n\n";
                            
                            if ($category !== null) {
                                $userState['category_id'] = $category;
                                $updated = true;
                                
                                // 檢查是否為模糊匹配（自動推斷）
                                $isAutoDetected = false;
                                if (!preg_match('/類別\s*[：:]/', $text) && !preg_match('/CategoryID\s*[：:]/', $text)) {
                                    // 檢查是否為數字輸入
                                    if (!preg_match('/類別\s+\d+/', $text)) {
                                        $isAutoDetected = true;
                                    }
                                }
                                
                                if ($isAutoDetected) {
                                    $response .= "🏷️ 類別：" . getCategoryName($category) . " (ID: {$category}) [自動推斷]\n";
                                } else {
                                    $response .= "🏷️ 類別：" . getCategoryName($category) . " (ID: {$category})\n";
                                }
                            }
                            
                            if ($title) {
                                $userState['title'] = $title;
                                $userState['needs_title'] = false;
                                $updated = true;
                                $response .= "📦 標題：{$title}\n";
                            }
                            
                            if ($price) {
                                $userState['price'] = $price;
                                $userState['needs_price'] = false;
                                $updated = true;
                                $response .= "💰 價格：{$price} 元\n";
                            }

                            if ($additional_description) {
                                $userState['additional_description'] = $additional_description;
                                $updated = true;
                                $response .= "📝 附加資訊：" . mb_substr($additional_description, 0, 20) . (mb_strlen($additional_description) > 20 ? '...' : '') . "\n";
                            }
                            
                            if ($updated) {
                                saveUserState($userId, $userState);
                                
                                $needsTitle = isset($userState['needs_title']) && $userState['needs_title'];
                                $needsPrice = isset($userState['needs_price']) && $userState['needs_price'];
                                
                                if ($needsTitle || $needsPrice) {
                                    $response .= "\n💡 還需要設定：\n";
                                    if ($needsTitle) $response .= "• 標題\n";
                                    if ($needsPrice) $response .= "• 價格\n";
                                    $response .= "\n💡 範例：標題 LED蠟燭 價格 1000";
                                } else {
                                    $response .= "\n🎉 設定完成！可以輸入「完成」來打包資料";
                                }
                                
                                // 如果是自動推斷的類別，提供修改提示
                                if (isset($isAutoDetected) && $isAutoDetected) {
                                    $response .= "\n\n💡 如需修改類別，請輸入：類別：其他";
                                }
                                
                                replyLineMessage($replyToken, $response);
                            } else {
                                replyLineMessage($replyToken, "❌ 請輸入有效的標題或價格。\n\n💡 範例：標題 LED蠟燭 價格 1000");
                            }
                        } else {
                            replyLineMessage($replyToken, "❌ 請先上傳圖片再設定標題和價格。");
                        }
                    }

                    else {
                        replyLineMessage($replyToken, 
                            "❓ 未知指令：{$text}\n\n" .
                            "📋 可用指令：\n" .
                            "• 開始 - 開始收集圖片\n" .
                            "• 狀態 - 查看目前進度\n" .
                            "• 類別表 - 查看類別對照表\n" .
                            "• 測試 - 測試系統連線\n" .
                            "• 取消 - 重新開始\n" .
                            "• 完成 - 打包資料\n\n" .
                            "📝 設定格式：\n" .
                            "• 類別：茶几 標題 LED蠟燭 價格 1000\n" .
                            "• 類別 10 標題 LED蠟燭 價格 1000\n" .
                            "• 內容 i5-7400 16GBRAM 500GBHDD\n" .
                            "• 或分開輸入：類別：茶几"
                        );
                    }
                    break;
            }
        }
        
        // 處理圖片訊息
        elseif ($message['type'] === 'image') {
            if ($userState['status'] !== 'collecting_images') {
                replyLineMessage($replyToken, "❌ 請先輸入「開始」來開始收集圖片。");
                break;
            }
            
            // 下載圖片
            $imageData = downloadLineImage($message['id'], LINE_ACCESS_TOKEN);
            if (!$imageData) {
                replyLineMessage($replyToken, "❌ 圖片下載失敗，請重試。");
                break;
            }
            
            // 建立使用者圖片目錄
            $userImageDir = __DIR__ . "/user_images/{$userId}";
            $originalDir = "{$userImageDir}/original";
            $compressedDir = "{$userImageDir}/compressed";
            
            if (!is_dir($originalDir)) {
                mkdir($originalDir, 0755, true);
            }
            
            
            // 儲存原始圖片
            $imageIndex = count($userState['images']);
            $originalFilename = "img_" . str_pad($imageIndex + 1, 3, '0', STR_PAD_LEFT) . ".jpg";
            $originalPath = "{$originalDir}/{$originalFilename}";
            
            if (file_put_contents($originalPath, $imageData) === false) {
                replyLineMessage($replyToken, "❌ 圖片儲存失敗，請重試。");
                break;
            }
            
            // 記錄圖片資訊
            $userState['images'][] = [
                'original_file' => "user_images/{$userId}/original/{$originalFilename}",
                'upload_time' => time(),
                'file_size' => strlen($imageData)
            ];
            
            // 如果是第一張圖片，需要設定標題和價格
            if (count($userState['images']) === 1) {
                $userState['needs_title'] = true;
                $userState['needs_price'] = true;
            }
            
            // 儲存狀態並記錄
            $saveResult = saveUserState($userId, $userState);
            logMessage('INFO', '圖片上傳完成', [
                'user_id' => $userId,
                'image_count' => count($userState['images']),
                'save_result' => $saveResult,
                'status' => $userState['status'],
                'original_size' => strlen($imageData)
            ]);
            
            // 修改：不再對每張圖片進行回覆，保持安靜收集
            /*
            $imageCount = count($userState['images']);
            if ($imageCount === 1) {
                // 第一張圖片，需要設定標題和價格
                replyLineMessage($replyToken, 
                    "✅ 第一張圖片上傳成功！\n\n" .
                    "📷 圖片資訊：\n" .
                    "• 圖片編號：{$imageCount}\n" .
                    "• 狀態：等待設定商品標題和價格\n\n" .
                    "💡 請輸入以下格式來設定：\n" .
                    "標題 LED蠟燭 價格 1000\n\n" .
                    "📋 其他指令：\n" .
                    "• 狀態 - 查看目前進度\n" .
                    "• 完成 - 打包資料"
                );
            } else {
                // 後續圖片，直接加入
                replyLineMessage($replyToken, 
                    "✅ 圖片上傳成功！\n\n" .
                    "📷 圖片資訊：\n" .
                    "• 圖片編號：{$imageCount}\n" .
                    "• 狀態：已加入商品圖片集\n\n" .
                    "💡 繼續上傳更多圖片或輸入「完成」來打包資料\n\n" .
                    "📋 其他指令：\n" .
                    "• 狀態 - 查看目前進度\n" .
                    "• 完成 - 打包資料"
                );
            }
            */
        }
    }
    
    // 回應成功
    http_response_code(200);
    echo 'OK';
    
} catch (Exception $e) {
    logMessage('ERROR', 'Webhook 處理異常', ['error' => $e->getMessage(), 'trace' => $e->getTraceAsString()]);
    http_response_code(500);
    echo 'Internal Server Error';
}

// 記錄請求結束
/**
 * 回覆 LINE 訊息（含重試機制）
 */
function replyLineMessage($replyToken, $text) {
    $maxRetries = 3;
    $retryDelay = 1; // 秒
    
    for ($attempt = 1; $attempt <= $maxRetries; $attempt++) {
        $result = sendLineMessage($replyToken, $text, $attempt);
        if ($result) {
            return true;
        }
        
        if ($attempt < $maxRetries) {
            logMessage('WARN', "LINE 回覆失敗，準備重試", [
                'attempt' => $attempt,
                'max_retries' => $maxRetries,
                'retry_delay' => $retryDelay
            ]);
            sleep($retryDelay);
        }
    }
    
    logMessage('ERROR', 'LINE 回覆最終失敗', [
        'max_retries' => $maxRetries,
        'text_length' => strlen($text)
    ]);
    return false;
}

/**
 * 發送 LINE 訊息（單次嘗試）
 */
function sendLineMessage($replyToken, $text, $attempt = 1) {
    $url = "https://api.line.me/v2/bot/message/reply";
    $data = [
        'replyToken' => $replyToken,
        'messages' => [
            ['type' => 'text', 'text' => $text]
        ]
    ];
    
    $jsonData = json_encode($data);
    if ($jsonData === false) {
        logMessage('ERROR', 'JSON 編碼失敗', ['data' => $data]);
        return false;
    }
    
    $ch = curl_init();
    if ($ch === false) {
        logMessage('ERROR', '無法初始化 cURL');
        return false;
    }
    
    curl_setopt_array($ch, [
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_TIMEOUT => 15,           // 減少總超時時間
        CURLOPT_CONNECTTIMEOUT => 5,     // 減少連線超時時間
        CURLOPT_HTTPHEADER => [
            'Content-Type: application/json',
            'Authorization: Bearer ' . LINE_ACCESS_TOKEN
        ],
        CURLOPT_POSTFIELDS => $jsonData,
        CURLOPT_SSL_VERIFYPEER => true,
        CURLOPT_SSL_VERIFYHOST => 2,
        CURLOPT_USERAGENT => 'LINE-BotSDK-PHP/1.0.0',
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_MAXREDIRS => 3,
        CURLOPT_DNS_USE_GLOBAL_CACHE => false,
        CURLOPT_DNS_CACHE_TIMEOUT => 2,
        CURLOPT_TCP_KEEPALIVE => 1,
        CURLOPT_TCP_KEEPIDLE => 120,
        CURLOPT_TCP_KEEPINTVL => 60
    ]);
    
    $startTime = microtime(true);
    $response = curl_exec($ch);
    $endTime = microtime(true);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $error = curl_error($ch);
    $curl_errno = curl_errno($ch);
    $responseTime = round(($endTime - $startTime) * 1000, 2);
    curl_close($ch);
    
    if ($error) {
        logMessage('ERROR', 'LINE 回覆失敗', [
            'attempt' => $attempt,
            'error' => $error,
            'curl_errno' => $curl_errno,
            'response_time' => $responseTime . 'ms',
            'url' => $url
        ]);
        return false;
    }
    
    if ($http_code !== 200) {
        logMessage('ERROR', 'LINE 回覆 HTTP 錯誤', [
            'attempt' => $attempt,
            'http_code' => $http_code, 
            'response' => $response,
            'response_time' => $responseTime . 'ms',
            'url' => $url
        ]);
        return false;
    }
    
    logMessage('INFO', 'LINE 回覆成功', [
        'attempt' => $attempt,
        'text_length' => strlen($text),
        'response_time' => $responseTime . 'ms'
    ]);
    return true;
}

/**
 * 驗證 LINE 簽章
 */
function verifyLineSignature($body, $signature) {
    $hash = hash_hmac('sha256', $body, LINE_CHANNEL_SECRET, true);
    $expected_signature = base64_encode($hash);
    
    if (!hash_equals($expected_signature, $signature)) {
        logMessage('ERROR', 'LINE 簽章驗證失敗');
        return false;
    }
    
    logMessage('INFO', 'LINE 簽章驗證成功');
    return true;
}

/**
 * 下載 LINE 圖片
 */
function downloadLineImage($messageId, $accessToken) {
    $url = "https://api-data.line.me/v2/bot/message/{$messageId}/content";
    
    $ch = curl_init();
    if ($ch === false) {
        logMessage('ERROR', '無法初始化 cURL（圖片下載）');
        return false;
    }
    
    curl_setopt_array($ch, [
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_CONNECTTIMEOUT => 10,
        CURLOPT_HTTPHEADER => [
            "Authorization: Bearer " . $accessToken,
            'User-Agent: LINE-BotSDK-PHP/1.0.0'
        ],
        CURLOPT_SSL_VERIFYPEER => true,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_MAXREDIRS => 3
    ]);
    
    $image_data = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $error = curl_error($ch);
    $curl_errno = curl_errno($ch);
    curl_close($ch);
    
    if ($error) {
        logMessage('ERROR', 'LINE 圖片下載失敗', [
            'error' => $error,
            'curl_errno' => $curl_errno,
            'message_id' => $messageId,
            'url' => $url
        ]);
        return false;
    }
    
    if ($http_code !== 200) {
        logMessage('ERROR', 'LINE 圖片下載 HTTP 錯誤', [
            'http_code' => $http_code,
            'message_id' => $messageId,
            'url' => $url
        ]);
        return false;
    }
    
    if (empty($image_data)) {
        logMessage('ERROR', 'LINE 圖片內容為空', ['message_id' => $messageId]);
        return false;
    }
    
    // 檢查是否為有效的圖片格式
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime_type = finfo_buffer($finfo, $image_data);
    finfo_close($finfo);
    
    if (!in_array($mime_type, ['image/jpeg', 'image/jpg', 'image/png', 'image/gif'])) {
        logMessage('ERROR', '無效的圖片格式', [
            'mime_type' => $mime_type,
            'message_id' => $messageId
        ]);
        return false;
    }
    
    logMessage('INFO', 'LINE 圖片下載成功', [
        'size' => strlen($image_data),
        'mime_type' => $mime_type,
        'message_id' => $messageId
    ]);
    return $image_data;
}

/**
 * 載入使用者狀態
 */
function loadUserState($userId) {
    $userStateFile = __DIR__ . "/user_states/{$userId}.json";
    
    // 定義預設的使用者狀態結構
    $defaultState = [
        'status' => '未開始',
        'images' => [],
        'start_time' => null,
        'needs_title' => false,
        'needs_price' => false,
        'title' => null,
        'price' => null,
        'additional_description' => null,
        'category_id' => DEFAULT_CATEGORY_ID
    ];

    if (file_exists($userStateFile)) {
        $content = file_get_contents($userStateFile);
        $state = json_decode($content, true);
        if ($state === null) {
            logMessage('ERROR', 'JSON 解析失敗', ['file' => $userStateFile, 'content' => $content]);
            return $defaultState; // 解析失敗時返回預設狀態
        }
        // 合併預設狀態和載入的狀態，載入的狀態會覆蓋預設值
        return array_merge($defaultState, $state);
    }
    
    return $defaultState; // 檔案不存在時返回預設狀態
}

/**
 * 儲存使用者狀態
 */
function saveUserState($userId, $state) {
    $userStateDir = __DIR__ . "/user_states";
    
    if (!is_dir($userStateDir)) {
        if (!mkdir($userStateDir, 0755, true)) {
            logMessage('ERROR', '無法建立目錄', ['dir' => $userStateDir]);
            return false;
        }
    }
    
    $userStateFile = "{$userStateDir}/{$userId}.json";
    $jsonContent = json_encode($state, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    
    if ($jsonContent === false) {
        logMessage('ERROR', 'JSON 編碼失敗', ['state' => $state]);
        return false;
    }
    
    $result = file_put_contents($userStateFile, $jsonContent);
    if ($result === false) {
        logMessage('ERROR', '無法寫入檔案', ['file' => $userStateFile]);
        return false;
    }
    
    logMessage('INFO', '使用者狀態已儲存', ['user_id' => $userId, 'file' => $userStateFile]);
    return true;
}

/**
 * 遞迴刪除目錄及其內容
 */
function deleteDirectory($dir) {
    if (!is_dir($dir)) return;
    $files = array_diff(scandir($dir), array('.', '..'));
    foreach ($files as $file) {
        $path = $dir . '/' . $file;
        if (is_dir($path)) {
            deleteDirectory($path);
        } else {
            unlink($path);
        }
    }
    rmdir($dir);
}

/**
 * 解析使用者輸入的類別
 */
function parseCategory($text) {
    // 移除多餘空白
    $text = trim($text);
    
    // 支援多種格式：
    // 1. 類別：茶几
    // 2. 類別 沙發
    // 3. 類別 10 (直接輸入ID)
    // 4. 直接輸入類別名稱：茶几
    // 5. CategoryID: 6
    
    // 檢查 "類別：" 格式
    if (preg_match('/類別\s*[：:]\s*(.+?)(?=\s+標題|\s+價格|\s+內容|$)/', $text, $matches)) {
        $categoryName = trim($matches[1]);
        return getCategoryId($categoryName);
    }
    
    // 檢查 "類別 " 格式（支援名稱和ID）
    if (preg_match('/類別\s+(.+?)(?=\s+標題|\s+價格|\s+內容|$)/', $text, $matches)) {
        $categoryInput = trim($matches[1]);
        
        // 先檢查是否為數字（直接輸入ID）
        if (is_numeric($categoryInput)) {
            $categoryId = (int)$categoryInput;
            return isValidCategoryId($categoryId) ? $categoryId : null;
        }
        
        // 如果不是數字，當作類別名稱處理
        return getCategoryId($categoryInput);
    }
    
    // 檢查 "CategoryID:" 格式
    if (preg_match('/CategoryID\s*[：:]\s*(\d+)/', $text, $matches)) {
        $categoryId = (int)$matches[1];
        return isValidCategoryId($categoryId) ? $categoryId : null;
    }
    
    // 檢查是否直接輸入類別名稱（模糊匹配）
    // 嘗試匹配類別名稱，不管是否有其他關鍵字
    foreach (CATEGORY_MAPPING as $name => $id) {
        if (strpos($text, $name) !== false) {
            return $id;
        }
    }
    
    return null;
}

/**
 * 根據類別名稱取得類別ID
 */
function getCategoryId($categoryName) {
    $categoryName = trim($categoryName);
    
    // 直接匹配
    if (isset(CATEGORY_MAPPING[$categoryName])) {
        return CATEGORY_MAPPING[$categoryName];
    }
    
    // 模糊匹配（包含關係）
    foreach (CATEGORY_MAPPING as $name => $id) {
        if (strpos($categoryName, $name) !== false || strpos($name, $categoryName) !== false) {
            return $id;
        }
    }
    
    return null;
}

/**
 * 檢查類別ID是否有效
 */
function isValidCategoryId($categoryId) {
    return in_array($categoryId, array_values(CATEGORY_MAPPING));
}

/**
 * 根據類別ID取得類別名稱
 */
function getCategoryName($categoryId) {
    foreach (CATEGORY_MAPPING as $name => $id) {
        if ($id == $categoryId) {
            return $name;
        }
    }
    return '其他';
}

/**
 * 生成類別對照表文字
 */
function generateCategoryTable() {
    $table = "📋 家具類別對照表\n\n";
    
    foreach (CATEGORY_MAPPING as $name => $id) {
        $table .= "• {$name} (ID: {$id})\n";
    }
    
    $table .= "\n💡 設定方式：\n";
    $table .= "• 類別：茶几 (明確設定)\n";
    $table .= "• 類別 沙發 (明確設定)\n";
    $table .= "• 類別 10 (直接輸入ID)\n";
    $table .= "• CategoryID: 6\n";
    $table .= "• 或直接輸入：茶几 (自動推斷)\n\n";
    $table .= "🤖 智能功能：系統會從商品描述中自動推斷類別\n";
    $table .= "💾 建議：將此表複製到 LINE 記事本！";
    
    return $table;
}

// 註冊關閉函式
register_shutdown_function('logRequestEnd');
?> 