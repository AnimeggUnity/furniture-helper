<?php
// 啟用 Session
session_start();

// 添加 CORS 標頭，允許跨域請求
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Accept');

// 處理 OPTIONS 預檢請求
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// 設定刪除密碼（建議修改為更安全的密碼）
$DELETE_PASSWORD = 'admin123';

// 檢查是否已認證的輔助函數
function isAuthenticated() {
    return isset($_SESSION['authenticated']) && $_SESSION['authenticated'] === true;
}

// 處理登入請求
if (isset($_POST['action']) && $_POST['action'] === 'login') {
    header('Content-Type: application/json');
    $password = $_POST['password'] ?? '';
    
    if ($password === $DELETE_PASSWORD) {
        $_SESSION['authenticated'] = true;
        echo json_encode(['success' => true, 'message' => '登入成功']);
    } else {
        echo json_encode(['success' => false, 'message' => '密碼錯誤']);
    }
    exit;
}

// 處理登出請求
if (isset($_POST['action']) && $_POST['action'] === 'logout') {
    header('Content-Type: application/json');
    $_SESSION['authenticated'] = false;
    session_destroy();
    echo json_encode(['success' => true, 'message' => '登出成功']);
    exit;
}

// 處理檢查認證狀態請求
if (isset($_GET['action']) && $_GET['action'] === 'check_auth') {
    header('Content-Type: application/json');
    echo json_encode(['authenticated' => isAuthenticated()]);
    exit;
}

// 處理刪除請求
if (isset($_POST['action']) && $_POST['action'] === 'delete' && isset($_POST['file'])) {
    header('Content-Type: application/json');
    
    // 檢查認證狀態
    if (!isAuthenticated()) {
        http_response_code(403);
        echo json_encode(['success' => false, 'message' => '未授權操作，請先登入']);
        exit;
    }
    
    $filename = $_POST['file'];
    $filepath = __DIR__ . "/packaged_data/" . $filename;
    
    // 安全性檢查
    if (strpos($filename, '..') !== false || !file_exists($filepath)) {
        http_response_code(404);
        echo json_encode(['success' => false, 'message' => '檔案不存在']);
        exit;
    }
    
    // 執行刪除
    if (unlink($filepath)) {
        echo json_encode(['success' => true, 'message' => '檔案刪除成功']);
    } else {
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => '檔案刪除失敗']);
    }
    exit;
}

// 處理獲取單一檔案詳情 (用於編輯)
if (isset($_GET['action']) && $_GET['action'] === 'get_details' && isset($_GET['file'])) {
    header('Content-Type: application/json');
    $filename = $_GET['file'];
    $filepath = __DIR__ . "/packaged_data/" . $filename;

    if (strpos($filename, '..') !== false || !file_exists($filepath)) {
        http_response_code(404);
        echo json_encode(['success' => false, 'message' => '檔案不存在']);
        exit;
    }

    $content = file_get_contents($filepath);
    echo $content;
    exit;
}

// 處理獲取圖片預覽
if (isset($_GET['action']) && $_GET['action'] === 'get_images' && isset($_GET['file'])) {
    header('Content-Type: application/json');
    $filename = $_GET['file'];
    $filepath = __DIR__ . "/packaged_data/" . $filename;

    if (strpos($filename, '..') !== false || !file_exists($filepath)) {
        http_response_code(404);
        echo json_encode(['success' => false, 'message' => '檔案不存在']);
        exit;
    }

    try {
        $jsonContent = file_get_contents($filepath);
        $jsonData = json_decode($jsonContent, true);
        
        if (!$jsonData || !isset($jsonData['Photos'])) {
            echo json_encode(['success' => true, 'images' => []]);
            exit;
        }

        $images = [];
        foreach ($jsonData['Photos'] as $index => $photo) {
            if (isset($photo['Photo']) && strpos($photo['Photo'], 'data:image/') === 0) {
                $images[] = [
                    'id' => $photo['PhotoID'] ?? "img_$index",
                    'src' => $photo['Photo']
                ];
            }
        }

        echo json_encode(['success' => true, 'images' => $images]);
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => '圖片解析失敗']);
    }
    exit;
}

// 處理更新請求
if (isset($_POST['action']) && $_POST['action'] === 'update' && isset($_POST['file'])) {
    header('Content-Type: application/json');
    
    // 檢查認證狀態
    if (!isAuthenticated()) {
        http_response_code(403);
        echo json_encode(['success' => false, 'message' => '未授權操作，請先登入']);
        exit;
    }
    
    $filename = $_POST['file'];
    $filepath = __DIR__ . "/packaged_data/" . $filename;

    if (strpos($filename, '..') !== false || !file_exists($filepath)) {
        http_response_code(404);
        echo json_encode(['success' => false, 'message' => '檔案不存在']);
        exit;
    }

    try {
        // 獲取原始 JSON 資料
        $jsonContent = file_get_contents($filepath);
        $jsonData = json_decode($jsonContent, true);

        if (!$jsonData) {
            throw new Exception('無法解析原始 JSON 檔案');
        }

        // 從 POST 請求中更新資料
        foreach ($_POST as $key => $value) {
            if ($key === 'action' || $key === 'file') continue;

            // 處理巢狀鍵名，例如 Photos[PhotoID]
            if (preg_match('/(\w+)\[(\w+)\]/', $key, $matches)) {
                $outerKey = $matches[1];
                $innerKey = $matches[2];
                if (isset($jsonData[$outerKey]) && is_array($jsonData[$outerKey])) {
                    $jsonData[$outerKey][$innerKey] = $value;
                }
            } else {
                // 處理非巢狀的頂層鍵
                if (isset($jsonData[$key])) {
                    $jsonData[$key] = $value;
                }
            }
        }

        // 特別處理 Photos 陣列，因為它不能直接從表單修改
        // 我們保留原始的 Photos 資料

        // 將更新後的資料寫回檔案
        $updatedJsonContent = json_encode($jsonData, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        if (file_put_contents($filepath, $updatedJsonContent) === false) {
            throw new Exception('無法寫入更新後的檔案');
        }

        echo json_encode(['success' => true, 'message' => '檔案更新成功']);

    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }
    exit;
}

// =================================================================
// 家具資料檔案列表與下載頁面
// 顯示最近 30 筆 JSON 檔案，支援直接下載
// =================================================================

// 檢查設定檔是否存在，如果不存在則導向設定精靈
if (!file_exists(__DIR__ . '/config.php')) {
    header('Location: setup_wizard.php');
    exit;
}

// 設定時區
date_default_timezone_set('Asia/Taipei');

// 處理下載請求
if (isset($_GET['action']) && $_GET['action'] === 'download' && isset($_GET['file'])) {
    $filename = $_GET['file'];
    $filepath = __DIR__ . "/packaged_data/" . $filename;
    
    // 安全性檢查
    if (strpos($filename, '..') !== false || !file_exists($filepath)) {
        http_response_code(404);
        exit('檔案不存在');
    }
    
    // 嘗試用標題作為下載檔名
    $downloadName = $filename;
    $jsonContent = @file_get_contents($filepath);
    if ($jsonContent) {
        $jsonData = json_decode($jsonContent, true);
        if ($jsonData && isset($jsonData['Name'])) {
            $title = trim($jsonData['Name']);
            if ($title !== '') {
                // 避免特殊字元
                $titleForDownload = preg_replace('/[^a-zA-Z0-9\x{4e00}-\x{9fa5}]/u', '', $title);
                if ($titleForDownload === '') $titleForDownload = 'furniture';
                $downloadName = $titleForDownload . '.json';
            }
        }
    }
    
    // 設定下載標頭
    header('Content-Type: application/json');
    header('Content-Disposition: attachment; filename="' . $downloadName . '"');
    header('Content-Length: ' . filesize($filepath));
    
    // 輸出檔案內容
    readfile($filepath);
    exit;
}

// 取得檔案列表
$packagedDir = __DIR__ . "/packaged_data";
$files = [];

if (is_dir($packagedDir)) {
    $fileList = glob($packagedDir . "/*.json");
    
    foreach ($fileList as $filepath) {
        $filename = basename($filepath);
        $fileTime = filemtime($filepath);
        $fileSize = filesize($filepath);
        
        // 嘗試從 JSON 檔案中讀取標題
        $title = '未命名商品';
        $price = '未設定價格';
        
        try {
            $jsonContent = file_get_contents($filepath);
            $jsonData = json_decode($jsonContent, true);
            
            if ($jsonData && isset($jsonData['Name'])) {
                $title = $jsonData['Name'];
            }
            if ($jsonData && isset($jsonData['InitPrice'])) {
                $price = $jsonData['InitPrice'] . ' 元';
            }
        } catch (Exception $e) {
            // 如果讀取失敗，使用檔名作為標題
            $title = pathinfo($filename, PATHINFO_FILENAME);
        }
        
        $files[] = [
            'filename' => $filename,
            'filepath' => $filepath,
            'time' => $fileTime,
            'size' => $fileSize,
            'date' => date('Y-m-d H:i:s', $fileTime),
            'title' => $title,
            'price' => $price
        ];
    }
    
    // 按時間排序（最新的在前面）
    usort($files, function($a, $b) {
        return $b['time'] - $a['time'];
    });
    
    // 只取最近 30 筆
    $files = array_slice($files, 0, 30);
}

// 處理 JSON API 請求
if (isset($_GET['format']) && $_GET['format'] === 'json') {
    // 告訴瀏覽器回傳的是 JSON 資料
    header('Content-Type: application/json');
    
    // 建立完整的下載 URL 的基礎部分
    $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? "https" : "http";
    $host = $_SERVER['HTTP_HOST'];
    // 這裡需要根據你的實際部署路徑調整
    // 假設 files.php 在 /webhook_standalone_test/files.php
    $base_url_for_download = $protocol . '://' . $host . dirname($_SERVER['PHP_SELF']) . '/files.php'; 

    $api_files = [];
    foreach ($files as $file) {
        $api_files[] = [
            'title' => $file['title'],
            'price' => $file['price'],
            'date' => $file['date'],
            // 構建每個檔案的下載連結
            'download_url' => $base_url_for_download . '?action=download&file=' . urlencode($file['filename'])
        ];
    }

    // 直接輸出 JSON 並結束腳本
    echo json_encode($api_files, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    exit;
}
?>
<?php if (!isset($_GET['format']) || $_GET['format'] !== 'json'): ?>
<!-- 密碼驗證已改為後端處理，無需在前端暴露密碼 -->
<?php endif; ?>
<!DOCTYPE html>
<html lang="zh-TW">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>家具資料檔案 (Bootstrap)</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .file-item .btn-group {
            min-width: 260px; /* 確保按鈕不會換行 */
        }
        .image-preview {
            max-width: 100%;
            height: auto;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            transition: transform 0.3s ease;
        }
        .image-preview:hover {
            transform: scale(1.05);
            cursor: pointer;
        }
        .image-item {
            position: relative;
            margin-bottom: 1rem;
        }
        .image-caption {
            position: absolute;
            bottom: 0;
            left: 0;
            right: 0;
            background: rgba(0,0,0,0.7);
            color: white;
            padding: 0.5rem;
            border-radius: 0 0 8px 8px;
            font-size: 0.85rem;
        }
        
        /* 懸停預覽樣式 */
        .image-hover-trigger {
            position: relative;
            display: inline-block;
        }
        
        .image-hover-trigger:hover .bi-image {
            color: #0d6efd !important;
            transform: scale(1.1);
            transition: all 0.2s ease;
        }
        
        
        .hover-preview {
            position: absolute;
            z-index: 1050;
            background: white;
            border: 2px solid #e9ecef;
            border-radius: 12px;
            box-shadow: 0 8px 25px rgba(0,0,0,0.15);
            padding: 20px;
            max-width: 400px;
            opacity: 0;
            transform: translateY(10px);
            transition: all 0.3s ease;
            pointer-events: none;
        }
        
        .hover-preview.show {
            opacity: 1;
            transform: translateY(0);
        }
        
        .hover-preview img {
            width: 300px;
            height: 300px;
            object-fit: cover;
            border-radius: 8px;
            display: block;
            margin: 0 auto;
        }
        
        .hover-preview .preview-info {
            text-align: center;
            margin-top: 8px;
            font-size: 0.8rem;
            color: #6c757d;
        }
        
        .hover-preview .loading {
            display: flex;
            align-items: center;
            justify-content: center;
            height: 300px;
            color: #6c757d;
        }
    </style>
</head>
<body>
    <div class="container mt-4">
        <div class="card">
            <div class="card-header text-center">
                <h1><i class="bi bi-archive-fill"></i> 家具資料檔案</h1>
                <p class="text-muted mb-0">最近 30 筆資料</p>
            </div>
            <div class="card-body">
                <!-- 登入區域 -->
                <div class="card mb-4">
                    <div class="card-body text-center" id="loginSection">
                        <div id="loginForm">
                            <div class="input-group mx-auto" style="max-width: 300px;">
                                <input type="password" id="loginPassword" class="form-control" placeholder="輸入刪除/編輯密碼">
                                <button class="btn btn-success" onclick="login()">
                                    <i class="bi bi-box-arrow-in-right"></i> 登入
                                </button>
                            </div>
                        </div>
                        <div id="logoutForm" style="display: none;">
                            <span class="text-success fw-bold me-3"><i class="bi bi-check-circle-fill"></i> 已登入</span>
                            <button class="btn btn-secondary btn-sm" onclick="logout()">
                                <i class="bi bi-box-arrow-right"></i> 登出
                            </button>
                        </div>
                    </div>
                </div>

                <?php if (empty($files)): ?>
                    <div class="alert alert-info text-center">
                        <i class="bi bi-info-circle"></i> 目前沒有可下載的檔案，請先使用 LINE Bot 建立資料。
                    </div>
                <?php else: ?>
                    <ul class="list-group">
                        <?php foreach ($files as $file): ?>
                            <li class="list-group-item d-flex justify-content-between align-items-center flex-wrap">
                                <div class="me-auto">
                                    <div class="fw-bold">
                                        📦 <?= htmlspecialchars($file['title']) ?>
                                        <span class="image-hover-trigger ms-2" 
                                              data-filename="<?= htmlspecialchars($file['filename']) ?>"
                                              data-title="<?= htmlspecialchars($file['title']) ?>">
                                            <i class="bi bi-image text-primary" style="cursor: pointer; font-size: 0.9rem;"></i>
                                        </span>
                                    </div>
                                    <small class="text-muted">
                                        <i class="bi bi-clock"></i> <?= $file['date'] ?> | 
                                        <i class="bi bi-file-earmark-binary"></i> <?= number_format($file['size'] / 1024, 1) ?> KB | 
                                        <span class="text-success fw-bold"><i class="bi bi-tags"></i> <?= htmlspecialchars($file['price']) ?></span>
                                    </small>
                                </div>
                                <div class="btn-group mt-2 mt-md-0">
                                    <a href="?action=download&file=<?= urlencode($file['filename']) ?>" class="btn btn-primary btn-sm">
                                        <i class="bi bi-download"></i> 下載
                                    </a>
                                    <button class="btn btn-info btn-sm" onclick="showImages('<?= htmlspecialchars($file['filename']) ?>', '<?= htmlspecialchars($file['title']) ?>')">
                                        <i class="bi bi-images"></i> 預覽
                                    </button>
                                    <button class="btn btn-warning btn-sm edit-btn" onclick="openEditModal('<?= htmlspecialchars($file['filename']) ?>')">
                                        <i class="bi bi-pencil-square"></i> 編輯
                                    </button>
                                    <button class="btn btn-danger btn-sm delete-btn" onclick="deleteFile('<?= htmlspecialchars($file['filename']) ?>', '<?= htmlspecialchars($file['title']) ?>')">
                                        <i class="bi bi-trash"></i> 刪除
                                    </button>
                                </div>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- 編輯彈出視窗 (Bootstrap Modal) -->
    <div class="modal fade" id="editModal" tabindex="-1" aria-labelledby="editModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-scrollable">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="editModalLabel">✏️ 編輯資料</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="editForm">
                        <input type="hidden" id="editFilename" name="file">
                        <div id="dynamicFormContainer"></div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">取消</button>
                    <button type="button" class="btn btn-primary" onclick="saveChanges()">💾 儲存變更</button>
                </div>
            </div>
        </div>
    </div>

    <!-- 圖片預覽彈出視窗 (Bootstrap Modal) -->
    <div class="modal fade" id="imageModal" tabindex="-1" aria-labelledby="imageModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-xl modal-dialog-scrollable">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="imageModalLabel">🖼️ 圖片預覽</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div id="imageContainer" class="row g-3">
                        <!-- 圖片將動態載入到這裡 -->
                    </div>
                    <div id="noImagesMessage" class="text-center text-muted" style="display: none;">
                        <i class="bi bi-image"></i> 此檔案沒有包含圖片
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">關閉</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // 檢查登入狀態
        function checkLoginStatus() {
            fetch('?action=check_auth')
                .then(response => response.json())
                .then(data => {
                    if (data.authenticated) {
                        showLoggedInState();
                    } else {
                        showLoggedOutState();
                    }
                })
                .catch(error => {
                    console.error('檢查認證狀態失敗:', error);
                    showLoggedOutState();
                });
        }

        // 登入
        function login() {
            const password = document.getElementById('loginPassword').value;
            if (!password) {
                alert('請輸入密碼');
                return;
            }

            const formData = new FormData();
            formData.append('action', 'login');
            formData.append('password', password);

            fetch(window.location.pathname, {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    showLoggedInState();
                    document.getElementById('loginPassword').value = '';
                } else {
                    alert('密碼錯誤');
                }
            })
            .catch(error => {
                console.error('登入失敗:', error);
                alert('登入時發生錯誤');
            });
        }

        // 登出
        function logout() {
            const formData = new FormData();
            formData.append('action', 'logout');

            fetch(window.location.pathname, {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                showLoggedOutState();
            })
            .catch(error => {
                console.error('登出失敗:', error);
                showLoggedOutState(); // 即使失敗也顯示登出狀態
            });
        }

        // 顯示已登入狀態
        function showLoggedInState() {
            document.getElementById('loginForm').style.display = 'none';
            document.getElementById('logoutForm').style.display = 'block';
            document.querySelectorAll('.delete-btn, .edit-btn').forEach(btn => {
                btn.style.display = 'inline-block';
            });
        }

        // 顯示未登入狀態
        function showLoggedOutState() {
            document.getElementById('loginForm').style.display = 'block';
            document.getElementById('logoutForm').style.display = 'none';
            document.querySelectorAll('.delete-btn, .edit-btn').forEach(btn => {
                btn.style.display = 'none';
            });
        }

        // 刪除檔案
        function deleteFile(filename, title) {
            if (!confirm(`確定要刪除檔案 "${title}" 嗎？`)) {
                return;
            }

            const formData = new FormData();
            formData.append('action', 'delete');
            formData.append('file', filename);

            fetch(window.location.pathname, {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    window.location.reload();
                } else {
                    alert('刪除失敗: ' + data.message);
                    if (data.message.includes('未授權')) {
                        logout();
                    }
                }
            })
            .catch(error => {
                console.error('刪除失敗:', error);
                alert('刪除時發生錯誤。');
            });
        }

        // Cookie 操作函數已移除，認證狀態由後端 Session 管理

        document.getElementById('loginPassword').addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                login();
            }
        });

        document.addEventListener('DOMContentLoaded', function() {
            checkLoginStatus();
            initImageHoverPreview();
        });

        // --- 懸停預覽功能 --- //
        let currentPreview = null;
        let hoverTimeout = null;

        function initImageHoverPreview() {
            const triggers = document.querySelectorAll('.image-hover-trigger');
            
            triggers.forEach(trigger => {
                const filename = trigger.dataset.filename;
                const title = trigger.dataset.title;
                
                trigger.addEventListener('mouseenter', (e) => {
                    clearTimeout(hoverTimeout);
                    hoverTimeout = setTimeout(() => {
                        showHoverPreview(e.target, filename, title);
                    }, 300); // 300ms 延遲避免誤觸
                });
                
                trigger.addEventListener('mouseleave', () => {
                    clearTimeout(hoverTimeout);
                    hideHoverPreview();
                });
                
                // 點擊直接開啟完整預覽
                trigger.addEventListener('click', (e) => {
                    e.preventDefault();
                    e.stopPropagation();
                    showImages(filename, title);
                });
            });
        }

        function showHoverPreview(trigger, filename, title) {
            // 移除現有預覽
            hideHoverPreview();
            
            // 建立預覽容器
            const preview = document.createElement('div');
            preview.className = 'hover-preview';
            preview.innerHTML = `
                <div class="loading">
                    <div class="spinner-border spinner-border-sm me-2" role="status"></div>
                    載入中...
                </div>
            `;
            
            document.body.appendChild(preview);
            currentPreview = preview;
            
            // 定位預覽框
            positionPreview(preview, trigger);
            
            // 載入第一張圖片
            loadFirstImage(preview, filename, title);
            
            // 顯示動畫
            setTimeout(() => {
                if (currentPreview === preview) {
                    preview.classList.add('show');
                }
            }, 50);
        }

        function hideHoverPreview() {
            if (currentPreview) {
                currentPreview.classList.remove('show');
                setTimeout(() => {
                    if (currentPreview && currentPreview.parentNode) {
                        currentPreview.parentNode.removeChild(currentPreview);
                    }
                    currentPreview = null;
                }, 300);
            }
        }

        function positionPreview(preview, trigger) {
            const rect = trigger.getBoundingClientRect();
            const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
            const scrollLeft = window.pageXOffset || document.documentElement.scrollLeft;
            
            let left = rect.left + scrollLeft + rect.width + 10;
            let top = rect.top + scrollTop;
            
            // 防止超出視窗右邊界 (預覽框寬度約400px)
            if (left + 400 > window.innerWidth + scrollLeft) {
                left = rect.left + scrollLeft - 410; // 顯示在左側
            }
            
            // 防止超出視窗下邊界 (預覽框高度約400px)
            if (top + 400 > window.innerHeight + scrollTop) {
                top = window.innerHeight + scrollTop - 420;
            }
            
            // 防止超出上邊界
            if (top < scrollTop) {
                top = scrollTop + 10;
            }
            
            // 防止超出左邊界
            if (left < scrollLeft) {
                left = rect.right + scrollLeft + 10; // 強制顯示在右側
            }
            
            preview.style.left = left + 'px';
            preview.style.top = top + 'px';
        }

        function loadFirstImage(preview, filename, title) {
            // 即時載入圖片
            fetch(`?action=get_images&file=${encodeURIComponent(filename)}`)
                .then(response => response.json())
                .then(data => {
                    if (data.success && data.images.length > 0) {
                        displayPreviewImage(preview, data.images, title);
                    } else {
                        preview.innerHTML = `
                            <div class="text-center text-muted p-3">
                                <i class="bi bi-image"></i><br>
                                此檔案沒有圖片
                            </div>
                        `;
                    }
                })
                .catch(error => {
                    console.error('載入圖片失敗:', error);
                    preview.innerHTML = `
                        <div class="text-center text-danger p-3">
                            <i class="bi bi-exclamation-triangle"></i><br>
                            載入失敗
                        </div>
                    `;
                });
        }

        function displayPreviewImage(preview, images, title) {
            if (images && images.length > 0) {
                const firstImage = images[0];
                const imageCount = images.length > 1 ? ` (共 ${images.length} 張)` : '';
                preview.innerHTML = `
                    <img src="${firstImage.src}" alt="${title}">
                    <div class="preview-info">
                        ${title}${imageCount}<br>
                        <small class="text-muted">點擊查看${images.length > 1 ? '全部' : '大圖'}</small>
                    </div>
                `;
            }
        }

        // --- 圖片預覽功能 --- //
        const imageModal = new bootstrap.Modal(document.getElementById('imageModal'));
        const imageContainer = document.getElementById('imageContainer');
        const noImagesMessage = document.getElementById('noImagesMessage');

        function showImages(filename, title) {
            // 設定 Modal 標題
            document.getElementById('imageModalLabel').textContent = `🖼️ ${title} - 圖片預覽`;
            
            // 清空容器
            imageContainer.innerHTML = '<div class="col-12 text-center"><div class="spinner-border" role="status"><span class="visually-hidden">載入中...</span></div></div>';
            noImagesMessage.style.display = 'none';
            
            // 顯示 Modal
            imageModal.show();
            
            // 獲取圖片資料
            fetch(`?action=get_images&file=${encodeURIComponent(filename)}`)
                .then(response => response.json())
                .then(data => {
                    imageContainer.innerHTML = '';
                    
                    if (data.success && data.images.length > 0) {
                        data.images.forEach((image, index) => {
                            const col = document.createElement('div');
                            col.className = 'col-md-6 col-lg-4';
                            
                            const imageItem = document.createElement('div');
                            imageItem.className = 'image-item';
                            
                            const img = document.createElement('img');
                            img.src = image.src;
                            img.className = 'image-preview';
                            img.alt = `圖片 ${index + 1}`;
                            img.onclick = () => openFullImage(image.src, `${title} - 圖片 ${index + 1}`);
                            
                            const caption = document.createElement('div');
                            caption.className = 'image-caption';
                            caption.textContent = image.id || `圖片 ${index + 1}`;
                            
                            imageItem.appendChild(img);
                            imageItem.appendChild(caption);
                            col.appendChild(imageItem);
                            imageContainer.appendChild(col);
                        });
                    } else {
                        noImagesMessage.style.display = 'block';
                    }
                })
                .catch(error => {
                    console.error('載入圖片失敗:', error);
                    imageContainer.innerHTML = '<div class="col-12 text-center text-danger"><i class="bi bi-exclamation-triangle"></i> 載入圖片時發生錯誤</div>';
                });
        }

        function openFullImage(src, title) {
            const fullImageModal = document.createElement('div');
            fullImageModal.className = 'modal fade';
            fullImageModal.innerHTML = `
                <div class="modal-dialog modal-dialog-centered modal-xl">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">${title}</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                        </div>
                        <div class="modal-body text-center">
                            <img src="${src}" class="img-fluid" style="max-height: 80vh;">
                        </div>
                    </div>
                </div>
            `;
            document.body.appendChild(fullImageModal);
            
            const modal = new bootstrap.Modal(fullImageModal);
            modal.show();
            
            fullImageModal.addEventListener('hidden.bs.modal', () => {
                document.body.removeChild(fullImageModal);
            });
        }

        // --- 編輯功能 (Bootstrap Modal) --- //
        const editModal = new bootstrap.Modal(document.getElementById('editModal'));
        const formContainer = document.getElementById('dynamicFormContainer');

        function openEditModal(filename) {
            fetch(`?action=get_details&file=${encodeURIComponent(filename)}`)
                .then(response => response.json())
                .then(data => {
                    if (data) {
                        formContainer.innerHTML = '';
                        document.getElementById('editFilename').value = filename;
                        
                        // 如果有圖片，先顯示圖片預覽區
                        if (data.Photos && data.Photos.length > 0) {
                            const imageSection = document.createElement('div');
                            imageSection.className = 'mb-4';
                            imageSection.innerHTML = `
                                <h6 class="text-primary"><i class="bi bi-images"></i> 商品圖片 (${data.Photos.length} 張)</h6>
                                <div class="row g-2" id="editModalImages"></div>
                            `;
                            formContainer.appendChild(imageSection);
                            
                            const imagesContainer = document.getElementById('editModalImages');
                            data.Photos.forEach((photo, index) => {
                                if (photo.Photo && photo.Photo.startsWith('data:image/')) {
                                    const col = document.createElement('div');
                                    col.className = 'col-md-3 col-sm-4 col-6';
                                    col.innerHTML = `
                                        <div class="image-item">
                                            <img src="${photo.Photo}" class="image-preview" alt="圖片 ${index + 1}" style="width: 100%; height: 100px; object-fit: cover;">
                                            <div class="image-caption">${photo.PhotoID || `圖片 ${index + 1}`}</div>
                                        </div>
                                    `;
                                    imagesContainer.appendChild(col);
                                }
                            });
                        }
                        
                        buildForm(data, formContainer);
                        editModal.show();
                    }
                })
                .catch(error => console.error('獲取資料失敗:', error));
        }

        function buildForm(data, parentElement, prefix = '') {
            for (const key in data) {
                const value = data[key];
                const inputName = prefix ? `${prefix}[${key}]` : key;

                if (key === 'Photos') continue;

                const formGroup = document.createElement('div');
                formGroup.className = 'mb-3';

                const label = document.createElement('label');
                label.htmlFor = inputName;
                label.className = 'form-label';
                label.textContent = key;
                formGroup.appendChild(label);

                if (typeof value === 'object' && value !== null && !Array.isArray(value)) {
                    const fieldset = document.createElement('fieldset');
                    fieldset.className = 'border p-2';
                    const legend = document.createElement('legend');
                    legend.className = 'fs-6 w-auto';
                    legend.textContent = key;
                    fieldset.appendChild(legend);
                    buildForm(value, fieldset, inputName);
                    formGroup.innerHTML = ''; // 清空 label
                    formGroup.appendChild(fieldset);
                } else {
                    let input;
                    if (typeof value === 'string' && value.length > 80) {
                        input = document.createElement('textarea');
                        input.rows = 4;
                    } else {
                        input = document.createElement('input');
                        input.type = (typeof value === 'number') ? 'number' : 'text';
                    }
                    input.id = inputName;
                    input.name = inputName;
                    input.className = 'form-control';
                    input.value = value;
                    formGroup.appendChild(input);
                }
                parentElement.appendChild(formGroup);
            }
        }

        function saveChanges() {
            const form = document.getElementById('editForm');
            const formData = new FormData(form);
            formData.append('action', 'update');

            fetch(window.location.pathname, {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    editModal.hide();
                    window.location.reload();
                } else {
                    alert('儲存失敗: ' + data.message);
                }
            })
            .catch(error => {
                console.error('儲存失敗:', error);
                alert('儲存時發生錯誤。');
            });
        }
    </script>
</body>
</html> 