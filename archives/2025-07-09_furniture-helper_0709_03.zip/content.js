(function () {
  // 注入 inject.js 到頁面
  const script = document.createElement('script');
  script.src = chrome.runtime.getURL('inject.js');
  script.onload = () => console.log('✅ inject.js 載入成功');
  script.onerror = () => console.error('❌ inject.js 載入失敗');
  document.documentElement.appendChild(script);

  // 將圖片轉換為 Base64 的函數
  async function convertImageToBase64(imageUrl) {
    return new Promise((resolve, reject) => {
      const img = new Image();
      img.crossOrigin = 'anonymous'; // 處理跨域問題
      
      img.onload = () => {
        try {
          const canvas = document.createElement('canvas');
          const ctx = canvas.getContext('2d');
          
          // 設定 canvas 尺寸
          canvas.width = img.naturalWidth;
          canvas.height = img.naturalHeight;
          
          // 繪製圖片到 canvas
          ctx.drawImage(img, 0, 0);
          
          // 轉換為 Base64
          const base64 = canvas.toDataURL('image/jpeg', 0.8); // 使用 JPEG 格式，品質 0.8
          resolve(base64);
        } catch (error) {
          reject(new Error(`Canvas 轉換失敗: ${error.message}`));
        }
      };
      
      img.onerror = () => {
        reject(new Error(`圖片載入失敗: ${imageUrl}`));
      };
      
      // 設定圖片來源
      img.src = imageUrl;
    });
  }

  /**
   * 將 Base64 字串轉換為 File 物件。
   * @param {string} base64String - 包含 data URI scheme 的 Base64 字串 (e.g., "data:image/png;base64,...")
   * @param {string} filename - 轉換後的檔案名稱
   * @returns {File} - 可用於上傳的 File 物件
   */
  function base64ToFile(base64String, filename = 'image.jpg') {
    try {
      const arr = base64String.split(',');
      const mime = arr[0].match(/:(.*?);/)[1]; // 從 "data:image/png;base64" 中提取 "image/png"
      const bstr = atob(arr[1]); // 解碼 Base64
      let n = bstr.length;
      const u8arr = new Uint8Array(n);

      while (n--) {
        u8arr[n] = bstr.charCodeAt(n);
      }

      const file = new File([u8arr], filename, { type: mime });
      console.log(`✅ Base64 轉 File 成功: ${filename} (${file.size} bytes, type: ${mime})`);
      return file;
    } catch (error) {
      console.error(`❌ Base64 轉 File 失敗: ${error.message}`);
      throw error;
    }
  }

  /**
   * 上傳單張圖片檔案到新北市再生家具的伺服器。
   * 這個 API 是一個純粹的檔案上傳接口，它接收圖片並回傳一個包含路徑的 JSON。
   *
   * @param {File} imageFile - 使用者透過 <input type="file"> 選擇的圖片檔案物件。
   * @returns {Promise<object>} - 伺服器回傳的 JSON 物件，預期包含 FilePath 等欄位。
   *                              例如: { FilePath: "/Static/Image/Upload/Product/uuid.jpg", ... }
   */
  async function uploadImage(imageFile) {
    const apiUrl = 'https://recycledstuff.ntpc.gov.tw/BidMgr/api/Product/UploadFile';

    console.log(`📤 開始上傳圖片: ${imageFile.name} (${imageFile.size} bytes)`);

    // 1. 建立一個 FormData 物件。
    const formData = new FormData();

    // 2. 將圖片檔案附加到 FormData 中。
    //    根據 Payload 分析，後端接收的欄位名是 "file"。
    formData.append('file', imageFile, imageFile.name);

    // 3. 使用 fetch 發起 POST 請求。
    //    當 body 是 FormData 時，瀏覽器會自動設定正確的 Content-Type (包含 boundary)，
    //    並且會自動附加當前網域的 cookie 用於認證。
    try {
      const response = await fetch(apiUrl, {
        method: 'POST',
        body: formData,
      });

      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`伺服器錯誤: ${response.status} ${response.statusText} - ${errorText}`);
      }

      // 4. 解析伺服器回傳的 JSON 資料並回傳。
      const result = await response.json();
      console.log('✅ 圖片上傳成功，伺服器回應:', result);
      return result;

    } catch (error) {
      console.error('❌ 圖片上傳失敗:', error);
      throw error; // 將錯誤向上拋出，以便呼叫者可以處理
    }
  }

  // 動態建立圖片預覽的函數
  function createImagePreview(imagePath, filename) {
    console.log(`🖼️ 建立圖片預覽: ${filename} -> ${imagePath}`);
    
    // 尋找預覽圖欄位的 file input
    const form = document.querySelector('.vxe-modal--box .el-form');
    if (!form) {
      console.error('❌ 未找到表單');
      return;
    }
    
    // 尋找預覽圖欄位
    const formItems = form.querySelectorAll('.el-form-item');
    let previewImageItem = null;
    let fileInput = null;
    
    formItems.forEach(item => {
      const label = item.querySelector('.el-form-item__label');
      if (label && label.textContent.trim() === '預覽圖') {
        previewImageItem = item;
        fileInput = item.querySelector('input[type="file"]');
      }
    });
    
    if (!previewImageItem || !fileInput) {
      console.error('❌ 未找到預覽圖欄位或 file input');
      return;
    }
    
    console.log(`✅ 找到預覽圖欄位:`, previewImageItem);
    console.log(`✅ 找到 file input:`, fileInput);
    
    // 分析表單驗證規則
    analyzeFormValidation(previewImageItem, fileInput);
    
    // 從 imagePath 建立一個 File 物件
    // 注意：這裡我們需要從 URL 下載圖片並轉換為 File
    fetch(imagePath)
      .then(response => {
        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`);
        }
        return response.blob();
      })
      .then(blob => {
        console.log(`✅ 成功下載圖片: ${filename} (${blob.size} bytes, ${blob.type})`);
        
        // 建立 File 物件
        const file = new File([blob], filename, { type: blob.type });
        console.log(`✅ 成功建立 File 物件: ${file.name} (${file.size} bytes, ${file.type})`);
        
        // 建立一個 DataTransfer 物件來模擬檔案選擇
        const dataTransfer = new DataTransfer();
        dataTransfer.items.add(file);
        
        // 設定 file input 的 files
        fileInput.files = dataTransfer.files;
        
        console.log(`✅ 成功設定 file input: ${filename}`);
        console.log(`🔍 調試：file input 的 files 屬性:`, fileInput.files);
        console.log(`🔍 調試：file input 的 files.length:`, fileInput.files.length);
        console.log(`🔍 調試：file input 的 value:`, fileInput.value);
        
        // 檢查設定是否成功
        if (fileInput.files && fileInput.files.length > 0) {
          const uploadedFile = fileInput.files[0];
          console.log(`✅ 檔案設定成功: ${uploadedFile.name} (${uploadedFile.size} bytes, ${uploadedFile.type})`);
          
          // 分析設定後的驗證狀態
          setTimeout(() => {
            analyzeValidationAfterFileSet(previewImageItem, fileInput);
            
            // 檢查表單驗證狀態
            const errorElement = previewImageItem.querySelector('.el-form-item__error');
            if (errorElement) {
              console.log(`🔍 設定檔案後的驗證錯誤: ${errorElement.textContent}`);
            } else {
              console.log(`✅ 設定檔案後沒有驗證錯誤`);
            }
            
            // 檢查 form-item 的 CSS 類別
            console.log(`🔍 Form Item CSS 類別: ${previewImageItem.classList.toString()}`);
            console.log(`🔍 是否有 is-error 類: ${previewImageItem.classList.contains('is-error')}`);
            console.log(`🔍 是否有 is-success 類: ${previewImageItem.classList.contains('is-success')}`);
          }, 500);
        } else {
          console.error(`❌ 檔案設定失敗: files.length = ${fileInput.files ? fileInput.files.length : 0}`);
        }
        
      })
      .catch(error => {
        console.error(`❌ 下載圖片失敗: ${error.message}`);
      });
  }
  
  // 分析表單驗證規則
  function analyzeFormValidation(formItem, fileInput) {
    console.log('🔍 分析表單驗證規則...');
    
    // 分析 form-item 的驗證相關屬性
    console.log('🔍 Form Item 分析:');
    console.log('  - classList:', formItem.classList.toString());
    console.log('  - 是否有 is-required 類:', formItem.classList.contains('is-required'));
    console.log('  - 是否有 is-error 類:', formItem.classList.contains('is-error'));
    console.log('  - 是否有 is-success 類:', formItem.classList.contains('is-success'));
    
    // 尋找驗證錯誤訊息
    const errorElement = formItem.querySelector('.el-form-item__error');
    if (errorElement) {
      console.log('  - 驗證錯誤訊息:', errorElement.textContent);
    } else {
      console.log('  - 沒有驗證錯誤訊息');
    }
    
    // 分析 file input 的屬性
    console.log('🔍 File Input 分析:');
    console.log('  - name:', fileInput.name);
    console.log('  - accept:', fileInput.accept);
    console.log('  - required:', fileInput.required);
    console.log('  - multiple:', fileInput.multiple);
    console.log('  - files.length:', fileInput.files ? fileInput.files.length : 0);
    console.log('  - value:', fileInput.value);
    
    // 尋找 Vue 相關的驗證屬性
    const vueValidationAttrs = ['v-model', 'v-validate', 'data-v-validate', 'data-v-model'];
    vueValidationAttrs.forEach(attr => {
      if (fileInput.hasAttribute(attr)) {
        console.log(`  - ${attr}:`, fileInput.getAttribute(attr));
      }
    });
    
    // 分析父級 Vue 組件
    const vueComponent = fileInput.closest('.el-upload, .upload-component, [class*="upload"]');
    if (vueComponent) {
      console.log('🔍 Vue 組件分析:');
      console.log('  - Vue 組件:', vueComponent);
      console.log('  - Vue 組件 classList:', vueComponent.classList.toString());
      
      // 尋找 Vue 組件內的驗證相關元素
      const uploadList = vueComponent.querySelector('.el-upload-list, .upload-list');
      if (uploadList) {
        console.log('  - 上傳列表:', uploadList);
        console.log('  - 上傳列表項目數量:', uploadList.children.length);
      }
    }
    
    // 分析整個表單的驗證規則
    const form = formItem.closest('.el-form');
    if (form) {
      console.log('🔍 表單驗證規則分析:');
      
      // 尋找表單的 rules 屬性或相關驗證配置
      const formRules = form.getAttribute('data-rules') || form.getAttribute('rules');
      if (formRules) {
        console.log('  - 表單驗證規則:', formRules);
      }
      
      // 尋找所有必填欄位
      const requiredFields = form.querySelectorAll('.is-required, [required]');
      console.log('  - 必填欄位數量:', requiredFields.length);
      requiredFields.forEach((field, index) => {
        const label = field.querySelector('.el-form-item__label');
        console.log(`    ${index + 1}. 必填欄位:`, label ? label.textContent : field.name || field.type);
      });
      
      // 尋找所有驗證錯誤
      const errorFields = form.querySelectorAll('.is-error, .el-form-item__error');
      console.log('  - 驗證錯誤數量:', errorFields.length);
      errorFields.forEach((field, index) => {
        console.log(`    ${index + 1}. 錯誤欄位:`, field);
      });
    }
  }
  
  // 分析設定檔案後的驗證狀態
  function analyzeValidationAfterFileSet(formItem, fileInput) {
    console.log('🔍 分析設定檔案後的驗證狀態...');
    
    // 檢查 form-item 的驗證狀態變化
    console.log('🔍 驗證狀態變化:');
    console.log('  - is-required:', formItem.classList.contains('is-required'));
    console.log('  - is-error:', formItem.classList.contains('is-error'));
    console.log('  - is-success:', formItem.classList.contains('is-success'));
    
    // 檢查 file input 的狀態
    console.log('🔍 File Input 狀態:');
    console.log('  - files.length:', fileInput.files ? fileInput.files.length : 0);
    console.log('  - value:', fileInput.value);
    
    // 檢查是否有驗證錯誤訊息
    const errorElement = formItem.querySelector('.el-form-item__error');
    if (errorElement) {
      console.log('  - 當前驗證錯誤:', errorElement.textContent);
    } else {
      console.log('  - 沒有驗證錯誤');
    }
    
    // 檢查 Vue 組件的狀態
    const vueComponent = fileInput.closest('.el-upload, .upload-component, [class*="upload"]');
    if (vueComponent) {
      console.log('🔍 Vue 組件狀態:');
      
      // 檢查上傳列表
      const uploadList = vueComponent.querySelector('.el-upload-list, .upload-list');
      if (uploadList) {
        console.log('  - 上傳列表項目數量:', uploadList.children.length);
        console.log('  - 上傳列表項目:', Array.from(uploadList.children).map(child => child.className));
      }
      
      // 檢查上傳按鈕狀態
      const uploadButton = vueComponent.querySelector('.el-upload__input, .upload-button');
      if (uploadButton) {
        console.log('  - 上傳按鈕狀態:', uploadButton.disabled ? 'disabled' : 'enabled');
      }
    }
    
    // 檢查整個表單的驗證狀態
    const form = formItem.closest('.el-form');
    if (form) {
      const allErrors = form.querySelectorAll('.el-form-item__error');
      const visibleErrors = Array.from(allErrors).filter(error => 
        error.style.display !== 'none' && error.style.visibility !== 'hidden'
      );
      console.log('🔍 表單整體驗證狀態:');
      console.log('  - 總錯誤數量:', allErrors.length);
      console.log('  - 可見錯誤數量:', visibleErrors.length);
      
      if (visibleErrors.length > 0) {
        visibleErrors.forEach((error, index) => {
          const formItem = error.closest('.el-form-item');
          const label = formItem ? formItem.querySelector('.el-form-item__label') : null;
          console.log(`    ${index + 1}. 錯誤: ${label ? label.textContent : '未知欄位'} - ${error.textContent}`);
        });
      }
    }
  }

  window.addEventListener('message', event => {
    if (event.source !== window || event.origin !== window.location.origin) return;
    const msg = event.data;
    if (!msg || !msg.source) {
      console.error('❌ 無效的消息格式', msg);
      return;
    }
    console.log('Received Message:', msg.source);
    if (msg.source === 'vue-stats') {
      if (!msg.monthly || !msg.yearly) {
        console.error('❌ vue-stats 數據格式錯誤', msg);
        alert('統計數據格式錯誤');
        return;
      }
      showModal(msg.monthly, msg.yearly);
    }
    if (msg.source === 'vue-export') {
      if (!Array.isArray(msg.data) || !msg.data.length) {
        alert('⚠️ 輕量匯出失敗，沒有資料');
        return;
      }
      exportToCSV(msg.data);
    }
    if (msg.source === 'vue-export-all') {
      if (!Array.isArray(msg.data) || !msg.data.length) {
        alert('⚠️ 全部匯出失敗，沒有資料');
        return;
      }
      console.log('Exporting Full CSV:', msg.data);
      exportAllToCSV(msg.data);
    }
    if (msg.source === 'vue-panel-data') {
      if (!Array.isArray(msg.data)) {
        console.error('❌ vue-panel-data 數據格式錯誤', msg);
        return;
      }
      buildPanel(msg.data);
    }
    if (msg.source === 'vue-print') {
      if (!Array.isArray(msg.data)) {
        console.error('❌ vue-print 數據格式錯誤', msg);
        alert('⚠️ 列印失敗，沒有資料');
        return;
      }
      printTable(msg.data);
    }
  });

  function showModal(monthly, yearly) {
    const currentYear = new Date().getFullYear().toString();
    const lines = [];
    Object.keys(monthly).filter(m => m.startsWith(currentYear + '-')).sort().reverse()
      .forEach(m => lines.push(`${m}：${monthly[m]} 筆`));
    Object.keys(yearly).filter(y => y !== currentYear).sort((a, b) => b - a)
      .forEach(y => lines.push(`${y}年：${yearly[y]} 筆`));

    let modal = document.getElementById('vue-stats-modal');
    if (!modal) {
      modal = document.createElement('div');
      modal.id = 'vue-stats-modal';
      Object.assign(modal.style, {
        position: 'fixed', top: '20%', left: '50%', transform: 'translateX(-50%)',
        background: '#fff', border: '0.5px solid #ddd', padding: '24px', zIndex: '9999',
        width: 'auto', maxWidth: '90%', maxHeight: '80%', overflow: 'auto',
        boxShadow: '0 2px 8px rgba(0,0,0,0.15)', borderRadius: '6px'
      });
      modal.innerHTML = `
        <span style="position:absolute; top:12px; right:16px; cursor:pointer; font-size:24px;"
              onclick="this.parentNode.style.display='none'">✖</span>
        <h3 style="font-size:24px; margin-top:0;">📊 年度/月份統計</h3>
        <ul id="vue-stats-list" style="padding-left:24px; margin:0; font-size:24px;"></ul>
      `;
      document.body.appendChild(modal);
    }
    const ul = modal.querySelector('#vue-stats-list');
    ul.innerHTML = '';
    lines.forEach(text => {
      const li = document.createElement('li');
      li.textContent = text;
      ul.appendChild(li);
    });
    modal.style.display = 'block';
  }

  function exportToCSV(data) {
    const keys = ['AutoID', 'Name', 'DistName', 'CreateDate'];
    const headers = ['編號', '名稱', '行政區', '建立日期'];
    const rows = [headers.join(',')];
    data.sort((a, b) => b.AutoID - a.AutoID);
    data.forEach(row => {
      const line = keys.map(k => {
        const value = k === 'CreateDate' ? (row[k] ?? '').slice(0, 10) : (row[k] ?? '');
        return `"${value.toString().replace(/"/g, '""')}"`;
      }).join(',');
      rows.push(line);
    });
    const blob = new Blob([rows.join('\n')], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `furniture-export-${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  }

  function exportAllToCSV(data) {
    const keys = ['AutoID', 'Name', 'CategoryName', 'DistName', 'CreateDate', 'Description', 'Length', 'Width', 'Height', 'DeliveryAddress', 'InitPrice', 'OriginPrice'];
    const headers = ['編號', '名稱', '類別', '行政區', '建立日期', '產品描述', '長', '寬', '高', '交貨地點', '起標價格', '原價'];
    const rows = [headers.join(',')];
    data.sort((a, b) => b.AutoID - a.AutoID);
    data.forEach(row => {
      const line = keys.map(k => {
        const value = k === 'CreateDate' ? (row[k] ?? '').slice(0, 10) : (row[k] ?? '');
        return `"${value.toString().replace(/"/g, '""')}"`;
      }).join(',');
      rows.push(line);
    });
    const blob = new Blob([rows.join('\n')], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `furniture-export-${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  }

  function showPhotoPreview(photos) {
    let modal = document.getElementById('photo-preview-modal');
    if (!modal) {
      modal = document.createElement('div');
      modal.id = 'photo-preview-modal';
      Object.assign(modal.style, {
        position: 'fixed', top: '10%', left: '50%', transform: 'translateX(-50%)',
        background: '#fff', border: '2px solid #007baf', padding: '20px', zIndex: '10000',
        maxHeight: '80%', overflow: 'auto', boxShadow: '0 4px 20px rgba(0,0,0,0.3)', borderRadius: '8px',
        minWidth: '600px', maxWidth: '90vw'
      });
      modal.innerHTML = `
        <span style="position:absolute; top:12px; right:16px; cursor:pointer; font-size:24px; color:#666;"
              onclick="this.parentNode.style.display='none'">✖</span>
        <h3 style="margin-top:0; margin-bottom:20px; color:#007baf; font-size:20px;">📷 圖片預覽</h3>
        <div id="photo-preview-container" style="display: flex; flex-wrap: wrap; gap: 15px; justify-content: center;"></div>
      `;
      document.body.appendChild(modal);
    }

    const container = modal.querySelector('#photo-preview-container');
    container.innerHTML = '';
    if (photos && Array.isArray(photos) && photos.length > 0) {
      photos.forEach((photo, index) => {
        const imgWrapper = document.createElement('div');
        imgWrapper.style.cssText = `
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 8px;
        `;
        
        const img = document.createElement('img');
        img.src = photo.Photo;
        img.style.cssText = `
          max-width: 400px;
          max-height: 400px;
          width: auto;
          height: auto;
          border: 1px solid #ddd;
          border-radius: 4px;
          box-shadow: 0 2px 8px rgba(0,0,0,0.1);
          cursor: pointer;
          transition: transform 0.2s ease;
        `;
        img.alt = `Photo ${index + 1}`;
        
        // 點擊圖片可以放大查看
        img.onclick = () => {
          const fullscreenModal = document.createElement('div');
          fullscreenModal.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            width: 100vw;
            height: 100vh;
            background: rgba(0,0,0,0.9);
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 10001;
            cursor: pointer;
          `;
          
          const fullscreenImg = document.createElement('img');
          fullscreenImg.src = photo.Photo;
          fullscreenImg.style.cssText = `
            max-width: 90vw;
            max-height: 90vh;
            width: auto;
            height: auto;
            border-radius: 4px;
          `;
          
          fullscreenModal.appendChild(fullscreenImg);
          document.body.appendChild(fullscreenModal);
          
          fullscreenModal.onclick = () => {
            fullscreenModal.remove();
          };
        };
        
        // 滑鼠懸停效果
        img.onmouseenter = () => {
          img.style.transform = 'scale(1.05)';
        };
        img.onmouseleave = () => {
          img.style.transform = 'scale(1)';
        };
        
        const imgLabel = document.createElement('div');
        imgLabel.textContent = `圖片 ${index + 1}`;
        imgLabel.style.cssText = `
          font-size: 12px;
          color: #666;
          font-weight: bold;
        `;
        
        imgWrapper.appendChild(img);
        imgWrapper.appendChild(imgLabel);
        container.appendChild(imgWrapper);
      });
    } else {
      container.innerHTML = '<p style="color:#666; font-size:16px;">無圖片可顯示</p>';
    }
    modal.style.display = 'block';
  }

  function buildPanel(data) {
    if (!Array.isArray(data) || !data.length) {
      console.warn('❌ 無有效資料');
      return;
    }

    const panelId = 'furniture-panel';
    const panel = document.getElementById(panelId);
    if (panel) panel.remove(); // 確保舊面板移除

    const newPanel = document.createElement('div');
    newPanel.id = panelId;
    newPanel.style = `
      position: fixed; top: 80px; right: 0;
      width: 320px; height: calc(100% - 100px);
      overflow-y: auto; background: white;
      border-left: 2px solid #007baf;
      box-shadow: -2px 0 5px rgba(0,0,0,0.2);
      font-family: 'Segoe UI', 'Noto Sans TC', sans-serif;
      z-index: 99999;
    `;
    newPanel.innerHTML = `
      <h2 style="margin: 0; background: #007baf; color: white; padding: 12px; font-size: 16px; display: flex; justify-content: space-between;">
        <span>📥 匯出家具資料</span>
        <button id="close-panel" style="background: none; border: none; color: white; font-size: 16px; cursor: pointer;">✖</button>
      </h2>
      <input type="text" id="panel-search" placeholder="輸入 AutoID 搜尋" style="width: calc(100% - 20px); padding: 8px; margin: 10px; border: 1px solid #ccc; border-radius: 4px;">
    `;

    data.sort((a, b) => b.AutoID - a.AutoID);
    data.forEach((item, i) => {
      const div = document.createElement('div');
      div.dataset.autoid = item.AutoID; // 新增 data-autoid 屬性
      // 根據索引設定明顯的色差
      const backgroundColor = i % 2 === 0 ? '#ffffff' : '#f0f2f5';
      div.style = `padding: 10px; border-bottom: 1px solid #eee; font-size: 14px; background-color: ${backgroundColor};`;
      div.innerHTML = `
        <div style="display: flex; justify-content: space-between; align-items: center;">
          <span>
            <span class="photo-preview-icon" style="cursor: pointer;">📦</span>
            <strong>${item.Name || '未命名'}</strong>
          </span>
          <div style="display: flex; gap: 5px;">
            <button style="background: #007baf; color: white; border: none; padding: 5px 10px; cursor: pointer; border-radius: 4px; font-size: 12px;" data-index="${i}">📦</button>
            <button class="package-download-btn" style="background: #28a745; color: white; border: none; padding: 5px 10px; cursor: pointer; border-radius: 4px; font-size: 12px;" data-index="${i}">📦</button>
          </div>
        </div>
        <div style="color: #666; font-size: 13px; margin-top: 4px;">
          🆔 ${item.AutoID} 🕒 ${(item.CreateDate || '').split('T')[0]}
          ${item.BidChecked ? 
            (item.HasBids ? 
              `<br><span style="background-color: #ffebee; padding: 2px 4px; border-radius: 3px;">💰 最高競標價: ${item.BidPrice} 元<br>👤 最高出價者: ${item.Bidder}</span>` : 
              '<br>📭 無競標資料'
            ) : 
            '<br>🔍 競標資料讀取中...'
          }
        </div>
      `;
      // 使用 setTimeout 將事件綁定推遲到下一個事件循環
      // 以確保 innerHTML 創建的元素已經被 DOM 解析和渲染
      setTimeout(() => {
        const photoIcon = div.querySelector('.photo-preview-icon');
        if (photoIcon) {
          photoIcon.addEventListener('click', () => showPhotoPreview(item.Photos));
        }

        const downloadBtn = div.querySelector('.download-btn');
        if (downloadBtn) {
          downloadBtn.onclick = () => {
            const { Photos, ...restOfItem } = item;
            const dataToExport = restOfItem;
            
            const name = item.Name || `item_${item.AutoID}`;
            const blob = new Blob([JSON.stringify(dataToExport, null, 2)], { type: 'application/json' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `${name}.json`;
            a.click();
            URL.revokeObjectURL(url);

            const base = location.origin;
            (Photos || []).forEach((p, j) => {
              const imgA = document.createElement('a');
              imgA.href = p.Photo.startsWith('http') ? p.Photo : base + p.Photo;
              imgA.download = `${name}_${j + 1}.jpg`;
              imgA.click();
            });
          };
        }

        const packageBtn = div.querySelector('.package-download-btn');
        if (packageBtn) {
          packageBtn.onclick = async () => {
            const name = item.Name || `item_${item.AutoID}`;
            console.log(`[打包下載] 開始處理: ${name}`);
            
            const originalText = packageBtn.textContent;
            packageBtn.textContent = '處理中...';
            packageBtn.disabled = true;

            const itemToPackage = JSON.parse(JSON.stringify(item));

            if (itemToPackage.Photos && itemToPackage.Photos.length > 0) {
              const conversionPromises = itemToPackage.Photos.map(async (photo) => {
                try {
                  const response = await fetch(photo.Photo);
                  const blob = await response.blob();
                  const base64String = await new Promise((resolve, reject) => {
                    const reader = new FileReader();
                    reader.onloadend = () => resolve(reader.result);
                    reader.onerror = reject;
                    reader.readAsDataURL(blob);
                  });
                  photo.base64Data = base64String;
                  photo.filename = photo.Photo.split('/').pop();
                } catch (error) {
                  console.error(`[打包下載] 轉換圖片失敗: ${photo.Photo}`, error);
                  photo.base64Data = null;
                }
                return photo;
              });
              itemToPackage.Photos = await Promise.all(conversionPromises);
            }

            const blob = new Blob([JSON.stringify(itemToPackage, null, 2)], { type: 'application/json' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `${name}_packaged.json`;
            a.click();
            URL.revokeObjectURL(url);

            console.log(`[打包下載] 完成: ${name}`);
            packageBtn.textContent = originalText;
            packageBtn.disabled = false;
          };
        }
      }, 0);
      
      // 打包下載按鈕事件處理器
      div.querySelector('.package-download-btn').onclick = async () => {
        const {
          AutoID, Name, CategoryName, DistName, CreateDate, Description,
          Length, Width, Height, DeliveryAddress, InitPrice, OriginPrice, Photos
        } = item;
        
        // 顯示載入提示
        const btn = div.querySelector('.package-download-btn');
        const originalText = btn.textContent;
        btn.textContent = '處理中...';
        btn.disabled = true;
        btn.style.background = '#6c757d';
        
        try {
          // 將圖片轉換為 Base64
          const photosWithBase64 = [];
          if (Photos && Array.isArray(Photos) && Photos.length > 0) {
            for (let j = 0; j < Photos.length; j++) {
              const photo = Photos[j];
              const photoUrl = photo.Photo.startsWith('http') ? photo.Photo : location.origin + photo.Photo;
              
              try {
                const base64 = await convertImageToBase64(photoUrl);
                photosWithBase64.push({
                  ...photo,
                  Photo: base64,
                  PhotoUrl: photoUrl // 保留原始URL作為參考
                });
              } catch (error) {
                console.error(`❌ 轉換圖片 ${j + 1} 失敗:`, error);
                // 如果轉換失敗，保留原始資料
                photosWithBase64.push({
                  ...photo,
                  PhotoUrl: photoUrl,
                  Error: '圖片轉換失敗'
                });
              }
            }
          }
          
          // 建立包含 Base64 圖片的完整資料
          const dataToExport = {
            AutoID,
            Name,
            CategoryName,
            DistName,
            CreateDate,
            Description,
            Length,
            Width,
            Height,
            DeliveryAddress,
            InitPrice,
            OriginPrice,
            Photos: photosWithBase64,
            ExportInfo: {
              ExportDate: new Date().toISOString(),
              ExportType: 'PackageDownload',
              ImageFormat: 'Base64',
              TotalImages: photosWithBase64.length
            }
          };
          
          // 下載 JSON 檔案
          const name = Name || `item_${i}`;
          const blob = new Blob([JSON.stringify(dataToExport, null, 2)], { type: 'application/json' });
          const url = URL.createObjectURL(blob);
          const a = document.createElement('a');
          a.href = url;
          a.download = `${name}_package.json`;
          a.click();
          URL.revokeObjectURL(url);
          
          console.log(`✅ 打包下載完成: ${name} (${photosWithBase64.length} 張圖片)`);
          
        } catch (error) {
          console.error('❌ 打包下載失敗:', error);
          alert('❌ 打包下載失敗，請稍後再試');
        } finally {
          // 恢復按鈕狀態
          btn.textContent = originalText;
          btn.disabled = false;
          btn.style.background = '#28a745';
        }
      };
      newPanel.appendChild(div);
    });

    document.body.appendChild(newPanel);
    document.getElementById('close-panel').onclick = () => {
      newPanel.remove(); // 銷毀面板
    };

    // 搜尋功能
    document.getElementById('panel-search').onkeyup = (e) => {
      const inputValue = e.target.value.trim();
      if (!inputValue) {
        // 清除高亮
        newPanel.querySelectorAll('[data-autoid]').forEach(item => {
          item.style.background = '';
        });
        return;
      }
      const item = newPanel.querySelector(`[data-autoid="${inputValue}"]`);
      if (item) {
        // 清除其他高亮
        newPanel.querySelectorAll('[data-autoid]').forEach(other => {
          if (other !== item) other.style.background = '';
        });
        // 滾動並高亮
        item.scrollIntoView({ behavior: 'smooth', block: 'center' });
        item.style.background = '#e6f3ff';
        setTimeout(() => item.style.background = '', 2000); // 2 秒後移除高亮
      } else {
        console.log('無匹配 AutoID:', inputValue);
      }
    };
  }

  function insertButtons() {
    const addBtn = document.querySelector('button.el-button.el-button--success');
    if (!addBtn || document.querySelector('#tm-stats-btn')) return;

    if (!addBtn.parentNode) {
      console.error('❌ 父節點未找到');
      return;
    }

    addBtn.onclick = () => {
      setTimeout(() => {
        const modal = document.querySelector('.vxe-modal--box');
        if (!modal) {
          console.log('❌ 未找到 vxe-modal--box');
          return;
        }

        const header = modal.querySelector('.vxe-modal--header');
        const title = header && header.querySelector('.vxe-modal--title');
        if (!header || !title || title.textContent !== '編輯視窗') {
          console.log('❌ 未找到 header 或標題不是「編輯視窗」', { header, title: title?.textContent });
          return;
        }

        setTimeout(() => {
          const modal = document.querySelector('.vxe-modal--box');
          if (!modal) {
            console.log('❌ 未找到 vxe-modal--box');
            return;
          }

          const header = modal.querySelector('.vxe-modal--header');
          if (!header || header.querySelector('#import-json-btn')) {
            console.log('❌ 未找到 header 或按鈕已存在');
            return;
          }

          // 插入匯入 JSON 按鈕
          const importButton = document.createElement('button');
          importButton.id = 'import-json-btn';
          importButton.innerHTML = '📥 匯入 JSON';
          importButton.className = 'el-button el-button--warning el-button--small';
          importButton.style.marginLeft = '10px';
          importButton.onclick = () => {
            const input = document.createElement('input');
            input.type = 'file';
            input.accept = '.json';
            input.onchange = (e) => {
              const file = e.target.files[0];
              if (file) {
                const reader = new FileReader();
                reader.onload = (e) => {
                  try {
                    const json = JSON.parse(e.target.result);
                    fillForm(json);
                  } catch (error) {
                    alert('❌ JSON 解析失敗: ' + error.message);
                  }
                };
                reader.readAsText(file);
              }
            };
            input.click();
          };
          
          // 插入分析表單按鈕
          const analyzeButton = document.createElement('button');
          analyzeButton.id = 'analyze-form-btn';
          analyzeButton.innerHTML = '🔍 分析表單';
          analyzeButton.className = 'el-button el-button--info el-button--small';
          analyzeButton.style.marginLeft = '10px';
          analyzeButton.onclick = () => {
            console.log('🔍 手動觸發表單分析...');
            const modal = document.querySelector('.vxe-modal--box');
            if (modal) {
              console.log('📝 分析當前編輯視窗表單...');
              analyzeFormBeforeSubmit(analyzeButton);
              analyzePreviewImageField(modal);
              
              // 分析所有表單欄位
              const forms = modal.querySelectorAll('form, .el-form');
              forms.forEach((form, index) => {
                console.log(`📝 分析表單 ${index + 1}:`, form);
                analyzeFormData(form);
                analyzeFormValidationStatus(form);
              });
            } else {
              console.log('❌ 未找到編輯視窗');
            }
          };
          
          header.appendChild(importButton);
          header.appendChild(analyzeButton);
          console.log('📥 匯入 JSON 和分析表單按鈕已插入到編輯視窗 header');
        }, 1000);
      }, 1000);
    };

    const statsBtn = document.createElement('button');
    statsBtn.id = 'tm-stats-btn';
    statsBtn.textContent = '📈 年度統計';
    statsBtn.className = 'el-button el-button--primary el-button--small';
    statsBtn.style.marginLeft = '5px';
    statsBtn.onclick = (e) => {
      // 防止事件冒泡和預設行為
      e.preventDefault();
      e.stopPropagation();
      
      const queryBtn = Array.from(document.querySelectorAll('button.el-button'))
        .find(b => /查\s*詢/.test(b.textContent));
      if (!queryBtn) {
        console.error('❌ 查詢按鈕未找到');
        alert('查詢按鈕未找到，請確認頁面已載入');
        return;
      }
      
      // 使用更安全的方式觸發查詢按鈕
      try {
        // 先嘗試直接觸發 Vue 事件
        if (queryBtn.__vue__ && queryBtn.__vue__.$emit) {
          queryBtn.__vue__.$emit('click');
        } else {
          // 如果沒有 Vue 實例，使用更安全的點擊方式
          const clickEvent = new MouseEvent('click', {
            bubbles: true,
            cancelable: true,
            view: window
          });
          queryBtn.dispatchEvent(clickEvent);
        }
        
        // 延遲發送統計請求
        setTimeout(() => {
          window.postMessage({ source: 'run-vue-stats' }, window.location.origin);
        }, 1000);
      } catch (error) {
        console.error('❌ 觸發查詢按鈕時發生錯誤:', error);
        // 如果觸發查詢按鈕失敗，直接嘗試獲取統計數據
        setTimeout(() => {
          window.postMessage({ source: 'run-vue-stats' }, window.location.origin);
        }, 500);
      }
    };

    const exportBtn = document.createElement('button');
    exportBtn.textContent = '📥';
    exportBtn.className = 'el-button el-button--warning el-button--small';
    exportBtn.style.marginLeft = '5px';
    exportBtn.onclick = () => {
      window.postMessage({ source: 'run-vue-export' }, window.location.origin);
    };

    const exportAllBtn = document.createElement('button');
    exportAllBtn.textContent = '📥 全部匯出';
    exportAllBtn.className = 'el-button el-button--warning el-button--small';
    exportAllBtn.style.marginLeft = '5px';
    exportAllBtn.onclick = () => {
      window.postMessage({ source: 'run-vue-export-all' }, window.location.origin);
    };

    const panelBtn = document.createElement('button');
    panelBtn.textContent = '📂 資料面板';
    panelBtn.className = 'el-button el-button--info el-button--small';
    panelBtn.style.marginLeft = '5px';
    panelBtn.onclick = () => {
      const panel = document.getElementById('furniture-panel');
      if (panel) {
        panel.remove(); // 銷毀面板
      } else {
        window.postMessage({ source: 'run-vue-panel' }, window.location.origin);
      }
    };

    const printBtn = document.createElement('button');
    printBtn.textContent = '🖨️ 列印表格';
    printBtn.className = 'el-button el-button--success el-button--small';
    printBtn.style.marginLeft = '5px';
    printBtn.onclick = () => {
      window.postMessage({ source: 'run-vue-print' }, window.location.origin);
    };

    // 新增一鍵匯入按鈕
    const quickImportBtn = document.createElement('button');
    quickImportBtn.textContent = '🚀 一鍵匯入';
    quickImportBtn.className = 'el-button el-button--danger el-button--small';
    quickImportBtn.style.marginLeft = '5px';
    quickImportBtn.title = '選擇包含 Base64 圖片的 JSON 檔案，直接送到伺服器';
    quickImportBtn.onclick = async (e) => {
      e.preventDefault();
      e.stopPropagation();
      
      console.log('🚀 開始一鍵匯入流程...');
      
      // 建立檔案選擇器
      const input = document.createElement('input');
      input.type = 'file';
      input.accept = '.json';
      input.style.display = 'none';
      
      input.addEventListener('change', async (event) => {
        const file = event.target.files[0];
        if (!file) return;
        
        try {
          console.log(`📁 選擇檔案: ${file.name}`);
          
          // 讀取 JSON 檔案
          const text = await file.text();
          const jsonData = JSON.parse(text);
          
          console.log('📋 JSON 資料解析成功，開始處理...');
          
          // 顯示處理中的提示
          const processingMsg = document.createElement('div');
          processingMsg.textContent = '🔄 正在處理資料，請稍候...';
          processingMsg.style = 'position:fixed;top:30px;right:30px;background:#fff;padding:16px 32px;border-radius:8px;box-shadow:0 2px 8px #0002;z-index:9999;font-size:18px;';
          document.body.appendChild(processingMsg);
          
          try {
            // 直接呼叫 API 送出
            const result = await directSubmitToAPI(jsonData);
            console.log('✅ 一鍵匯入完成！', result);
            processingMsg.remove();
          } catch (error) {
            processingMsg.remove();
            throw error;
          }
        } catch (error) {
          console.error('❌ 一鍵匯入失敗:', error);
          alert(`❌ 一鍵匯入失敗: ${error.message}`);
        }
        document.body.removeChild(input);
      });
      document.body.appendChild(input);
      input.click();
    };
    addBtn.parentNode.insertBefore(quickImportBtn, printBtn.nextSibling);

    if (!statsBtn || !exportBtn || !exportAllBtn || !panelBtn || !printBtn) {
      console.error('❌ 按鈕未正確定義');
      return;
    }

    addBtn.parentNode.insertBefore(statsBtn, addBtn.nextSibling);
    addBtn.parentNode.insertBefore(exportBtn, statsBtn.nextSibling);
    addBtn.parentNode.insertBefore(exportAllBtn, exportBtn.nextSibling);
    addBtn.parentNode.insertBefore(panelBtn, exportAllBtn.nextSibling);
    addBtn.parentNode.insertBefore(printBtn, panelBtn.nextSibling);
    console.log('✅ 已插入統計、輕量匯出、全部匯出、資料面板、列印表格按鈕');
  }

  // JSON 匯入功能相關函數
  // 強制更新 Vue 組件
  function forceVueUpdate(input, value) {
    // 獲取欄位標籤用於日誌
    const label = input.closest('.el-form-item')?.querySelector('.el-form-item__label')?.textContent.trim() || '未知欄位';
    
    console.log(`🔧 設定欄位 "${label}": 原始值="${input.value}", 新值="${value}"`);
    
    // 直接設定值
    input.value = value;
    
    // 觸發 Vue 的響應式更新
    input.dispatchEvent(new Event('input', { bubbles: true }));
    input.dispatchEvent(new Event('change', { bubbles: true }));
    
    // 如果是數字輸入框，確保值為數字
    if (input.type === 'number' && typeof value === 'string') {
      const numValue = parseFloat(value);
      if (!isNaN(numValue)) {
        input.value = numValue;
        console.log(`🔧 數字欄位 "${label}": 轉換為數字 ${numValue}`);
      }
    }
    
    // 額外觸發更多事件確保更新
    input.dispatchEvent(new Event('blur', { bubbles: true }));
    input.dispatchEvent(new Event('focus', { bubbles: true }));
    
    console.log(`✅ 欄位 "${label}" 設定完成: value="${input.value}", type="${input.type}"`);
  }

  // 驗證表單資料
  function validateFormData() {
    const form = document.querySelector('.vxe-modal--box .el-form');
    if (!form) {
      console.error('❌ 未找到表單');
      return;
    }

    const formItems = form.querySelectorAll('.el-form-item');
    formItems.forEach(item => {
      const label = item.querySelector('.el-form-item__label');
      const input = item.querySelector('input, textarea, select');
      
      if (label && input) {
        const labelText = label.textContent.trim();
        const value = input.value;
        const display = input.type === 'file' ? input.files?.[0]?.name || '無檔案' : value;
        console.log(`✅ 欄位驗證: ${labelText} = ${display}`);
      }
    });
  }

  // 增強版填充表單函數（支援 Element UI Select 元件）
  async function fillForm(json) {
    const form = document.querySelector('.vxe-modal--box .el-form');
    if (!form) {
      console.error('❌ 未找到表單');
      return;
    }

    // 先處理非 Select 欄位
    const nonSelectItems = [];
    const selectItems = [];

    const formItems = form.querySelectorAll('.el-form-item');
    formItems.forEach(item => {
      const label = item.querySelector('.el-form-item__label');
      const input = item.querySelector('input, textarea, select');
      
      if (!label || !input) return;
      
      const labelText = label.textContent.trim();
      let value = '';

      // 根據標籤文字映射 JSON 欄位
      switch (labelText) {
        case '品名':
          value = json.Name || '';
          break;
        case '類別':
          value = json.CategoryName || '';
          break;
        case '行政區':
          value = json.DistName || '';
          break;
        case '產品描述':
          value = json.Description || '';
          break;
        case '長':
          value = json.Length !== undefined && json.Length !== null ? json.Length : '';
          console.log(`🔍 JSON Length 欄位: "${json.Length}" (類型: ${typeof json.Length})`);
          break;
        case '寬':
          value = json.Width !== undefined && json.Width !== null ? json.Width : '';
          console.log(`🔍 JSON Width 欄位: "${json.Width}" (類型: ${typeof json.Width})`);
          break;
        case '高':
          value = json.Height !== undefined && json.Height !== null ? json.Height : '';
          console.log(`🔍 JSON Height 欄位: "${json.Height}" (類型: ${typeof json.Height})`);
          break;
        case '交貨地點':
          value = json.DeliveryAddress || '';
          break;
        case '起標價格':
          value = json.InitPrice || '';
          break;
        case '原價':
          value = json.OriginPrice || '';
          break;
        default:
          return;
      }

      // 特殊處理：數值為 0 時也要處理（長寬高欄位）
      if (value === '' && !(labelText === '長' || labelText === '寬' || labelText === '高')) {
        return;
      }

      // 分類處理
      if (input.type === 'text' && (labelText === '類別' || labelText === '行政區')) {
        selectItems.push({ item, labelText, input, value });
      } else {
        // 特殊處理長寬高欄位
        if (labelText === '長' || labelText === '寬' || labelText === '高') {
          console.log(`📏 處理尺寸欄位 "${labelText}": JSON值="${value}", 類型="${typeof value}"`);
          // 處理各種可能的值：0, "0", "", null, undefined
          let numValue;
          if (value === 0 || value === '0') {
            numValue = 0;
          } else if (value === '' || value === null || value === undefined) {
            numValue = 0; // 空值也設為 0
          } else {
            numValue = value;
          }
          console.log(`📏 尺寸欄位 "${labelText}" 最終值: ${numValue}`);
          nonSelectItems.push({ item, labelText, input, value: numValue });
        } else {
          nonSelectItems.push({ item, labelText, input, value });
        }
      }
    });

    // 先處理非 Select 欄位
    nonSelectItems.forEach(({ input, value }) => {
      forceVueUpdate(input, value);
    });

    // 順序處理 Select 欄位
    for (const { labelText, input, value } of selectItems) {
      await processSelectField(labelText, input, value);
    }

    // 處理拍賣期間欄位（自動設定現在時間）
    await processAuctionPeriod();

    // 處理圖片上傳（如果是打包的 JSON）
    if (json.Photos && Array.isArray(json.Photos) && json.Photos.length > 0) {
      console.log(`🖼️ 檢測到 ${json.Photos.length} 張圖片，開始處理圖片上傳...`);
      
      // 檢查是否為打包的 JSON（包含 Base64 資料）
      const hasBase64Images = json.Photos.some(photo => photo.Photo && photo.Photo.startsWith('data:image'));
      
      if (hasBase64Images) {
        console.log(`📦 檢測到打包的 JSON，開始上傳 Base64 圖片...`);
        await uploadImagesFromPackagedJson(json.Photos);
      } else {
        console.log(`📋 檢測到普通 JSON，跳過圖片上傳`);
      }
    }
  }

  // 從打包的 JSON 上傳圖片的函數
  async function uploadImagesFromPackagedJson(photos) {
    console.log(`🚀 開始批量上傳 ${photos.length} 張圖片...`);
    
    // 清空現有的視覺預覽（如果有的話）
    const form = document.querySelector('.vxe-modal--box .el-form');
    if (form) {
      const formItems = form.querySelectorAll('.el-form-item');
      formItems.forEach(item => {
        const label = item.querySelector('.el-form-item__label');
        if (label && label.textContent.trim() === '預覽圖') {
          const previewContainer = item.querySelector('.image-preview-container');
          if (previewContainer) {
            console.log('🧹 清空現有視覺預覽');
            previewContainer.innerHTML = '';
          }
        }
      });
    }
    
    const uploadedImages = [];
    
    // 使用 Promise.all 來並行處理所有圖片的上傳（根據您的建議）
    const uploadPromises = photos.map(async (photo, index) => {
      try {
        // 檢查是否有 Base64 資料
        if (!photo.Photo || !photo.Photo.startsWith('data:image')) {
          console.warn(`⚠️ 圖片 ${index + 1} 沒有 Base64 資料，跳過`);
          return null;
        }
        
        // 取得檔案名稱
        const filename = photo.filename || photo.PhotoID || `upload_${index + 1}.jpg`;
        
        console.log(`📤 處理第 ${index + 1}/${photos.length} 張圖片: ${filename}`);
        
        // 將 Base64 轉換為 File 物件
        const imageFile = base64ToFile(photo.Photo, filename);
        
        // 呼叫我們優化後的 uploadImage 函數
        const uploadResult = await uploadImage(imageFile);
        
        return {
          filename,
          uploadResult,
          originalPhoto: photo
        };
        
      } catch (error) {
        console.error(`❌ 第 ${index + 1} 張圖片處理失敗: ${error.message}`);
        return null;
      }
    });
    
    // 等待所有圖片上傳完成
    const uploadResults = await Promise.all(uploadPromises);
    
    console.log('[圖片處理] 所有圖片上傳完成！', uploadResults);
    
    // 動態渲染預覽（無需重整）
    uploadResults.forEach(result => {
      if (result && result.uploadResult) {
        // 伺服器回應可能是字串 URL 或包含 FilePath 的物件
        let imageUrl;
        if (typeof result.uploadResult === 'string') {
          // 直接是 URL 字串
          imageUrl = result.uploadResult;
        } else if (result.uploadResult.FilePath) {
          // 包含 FilePath 欄位的物件
          imageUrl = result.uploadResult.FilePath.startsWith('http') 
            ? result.uploadResult.FilePath 
            : `https://recycledstuff.ntpc.gov.tw${result.uploadResult.FilePath}`;
        } else {
          console.warn(`⚠️ 無法解析上傳結果格式:`, result.uploadResult);
          return;
        }
        
        // 動態建立圖片預覽
        createImagePreview(imageUrl, result.filename);
        
        uploadedImages.push({
          filename: result.filename,
          filePath: imageUrl,
          originalPhoto: result.originalPhoto
        });
        
        console.log(`✅ 圖片預覽建立完成: ${result.filename} -> ${imageUrl}`);
      }
    });
    
    console.log(`🎉 圖片上傳完成！成功上傳 ${uploadedImages.length}/${photos.length} 張圖片`);
    
    // 顯示完成訊息
    if (uploadedImages.length > 0) {
      const message = `✅ 成功上傳 ${uploadedImages.length} 張圖片並建立預覽`;
      console.log(message);
      
      // 顯示完成通知
      const notification = document.createElement('div');
      notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: #28a745;
        color: white;
        padding: 12px 20px;
        border-radius: 6px;
        z-index: 10000;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        font-size: 14px;
      `;
      notification.textContent = message;
      document.body.appendChild(notification);
      
      // 3秒後自動移除
      setTimeout(() => {
        if (notification.parentNode) {
          notification.remove();
        }
      }, 3000);
      

    }
    
    return uploadedImages;
  }

  // 處理單個 Select 欄位的函數
  function processSelectField(labelText, input, value) {
    return new Promise((resolve) => {
      const elSelect = input.closest('.el-select');
      if (elSelect) {
        // 【日誌點 1】: 確認我們開始處理哪個欄位
        console.log(`[偵錯] 1. 開始處理欄位: "${labelText}"，目標值: "${value}"`);

        // 【日誌點 2】: 模擬點擊輸入框，準備觸發下拉選單
        console.log(`[偵錯] 2. 準備模擬點擊 <input> 以顯示下拉選單。`);
        input.click();

        // 延遲一下確保下拉選單開啟
        setTimeout(() => {
          // 【日誌點 3】: 延遲後，開始尋找下拉選單
          console.log(`[偵錯] 3. (100ms 後) 開始在整個 document 中尋找下拉選單 (.el-select-dropdown)...`);

          // 尋找所有可能的下拉選單，而不只是一個
          const allDropdowns = document.querySelectorAll('.el-select-dropdown');

          // 【日誌點 4】: 報告找到了多少個下拉選單
          console.log(`[偵錯] 4. 找到了 ${allDropdowns.length} 個 .el-select-dropdown 元素。`);

          if (allDropdowns.length === 0) {
            console.error(`[偵錯] 致命錯誤：點擊後未找到任何下拉選單元素！`);
            // 使用備用方案
            forceVueUpdate(input, value);
            input.dispatchEvent(new Event('input', { bubbles: true }));
            input.dispatchEvent(new Event('change', { bubbles: true }));
            resolve();
            return; // 提前終止
          }

          // 遍歷所有找到的下拉選單，並分析它們的狀態
          allDropdowns.forEach((dropdown, index) => {
            const isVisible = window.getComputedStyle(dropdown).display !== 'none';
            console.log(`[偵錯] 4.${index + 1}. 分析第 ${index + 1} 個下拉選單:`, {
              '是否可見': isVisible,
              'HTML內容 (前50個字元)': dropdown.innerHTML.substring(0, 50) + '...',
              'DOM元素': dropdown
            });
          });

          // 找出那個「可見」的下拉選單來操作
          const visibleDropdown = Array.from(allDropdowns).find(d => window.getComputedStyle(d).display !== 'none');

          if (!visibleDropdown) {
            console.error(`[偵錯] 致命錯誤：找到了 ${allDropdowns.length} 個下拉選單，但沒有一個是可見的！`);
            // 使用備用方案
            forceVueUpdate(input, value);
            input.dispatchEvent(new Event('input', { bubbles: true }));
            input.dispatchEvent(new Event('change', { bubbles: true }));
            resolve();
            return;
          }

          // 【日誌點 5】: 確認我們將在哪個下拉選單中尋找選項
          console.log(`[偵錯] 5. 已鎖定可見的下拉選單。準備在其中尋找選項...`, visibleDropdown);

          const options = visibleDropdown.querySelectorAll('.el-select-dropdown__item');

          // 【日誌點 6】: 報告在可見的下拉選單中找到了多少選項
          console.log(`[偵錯] 6. 在可見下拉選單中找到了 ${options.length} 個選項。`);

          const matchedOption = Array.from(options).find(option =>
            option.textContent.trim() === value
          );

          if (matchedOption) {
            // 【日誌點 7 - 成功路徑】: 報告找到了匹配的選項，並準備點擊
            console.log(`[偵錯] 7. 成功！找到匹配的選項: "${matchedOption.textContent.trim()}"。準備點擊。`, matchedOption);
            matchedOption.click();
            console.log(`[偵錯] 8. 模擬點擊完成。`);
            
            // 觸發必要的事件
            input.dispatchEvent(new Event('input', { bubbles: true }));
            input.dispatchEvent(new Event('change', { bubbles: true }));
          } else {
            // 【日誌點 7 - 失敗路徑】: 報告未找到匹配的選項
            console.error(`[偵錯] 7. 失敗！在可見的 ${options.length} 個選項中，未找到文字為 "${value}" 的選項。`);
            // 列出所有可用的選項，方便比對
            const availableOptions = Array.from(options).map(o => o.textContent.trim());
            console.log('[偵錯] 可用選項列表:', availableOptions);
            
            // 使用備用方案
            forceVueUpdate(input, value);
            input.dispatchEvent(new Event('input', { bubbles: true }));
            input.dispatchEvent(new Event('change', { bubbles: true }));
          }

          // 延遲一下再處理下一個欄位，確保動畫完成
          setTimeout(() => {
            resolve();
          }, 200);

        }, 100); // 保持 100ms 延遲

      } else {
        // 使用備用方案
        forceVueUpdate(input, value);
        input.dispatchEvent(new Event('input', { bubbles: true }));
        input.dispatchEvent(new Event('change', { bubbles: true }));
        resolve();
      }
    });
  }

  // 處理拍賣期間欄位（自動設定現在時間）
  async function processAuctionPeriod() {
    console.log('🕒 開始處理拍賣期間欄位...');
    
    const form = document.querySelector('.vxe-modal--box .el-form');
    if (!form) {
      console.error('❌ 未找到表單');
      return;
    }

    // 找到拍賣期間(起)和拍賣期間(迄)欄位
    const formItems = form.querySelectorAll('.el-form-item');
    let startField = null;
    let endField = null;

    formItems.forEach(item => {
      const label = item.querySelector('.el-form-item__label');
      if (label) {
        const labelText = label.textContent.trim();
        if (labelText === '拍賣期間(起)') {
          startField = item.querySelector('input');
        } else if (labelText === '拍賣期間(迄)') {
          endField = item.querySelector('input');
        }
      }
    });

    if (!startField || !endField) {
      console.error('❌ 未找到拍賣期間欄位');
      return;
    }

    console.log('✅ 找到拍賣期間欄位，準備自動設定時間...');

    // 處理拍賣期間(起) - 設定為現在時間
    await setCurrentTime(startField, '拍賣期間(起)');
    
    // 等待一下讓系統自動填入拍賣期間(迄)
    await new Promise(resolve => setTimeout(resolve, 500));
    
    // 檢查拍賣期間(迄)是否已經自動填入
    const endValue = endField.value;
    if (!endValue || endValue.trim() === '') {
      console.log('⚠️ 拍賣期間(迄)未自動填入，手動設定...');
      // 如果沒有自動填入，才手動設定
      await setCurrentTime(endField, '拍賣期間(迄)', 30);
    } else {
      console.log(`✅ 拍賣期間(迄)已自動填入: ${endValue}`);
    }
  }

  // 設定時間的輔助函數
  async function setCurrentTime(input, fieldName, daysToAdd = 0) {
    return new Promise((resolve) => {
      console.log(`🕒 處理 ${fieldName} 欄位...`);
      
      // 確保輸入框可見且可點擊
      input.scrollIntoView({ behavior: 'smooth', block: 'center' });
      
      // 點擊輸入框開啟日期選擇器
      input.click();
      input.focus();
      console.log(`🕒 已點擊 ${fieldName} 輸入框，等待日期選擇器開啟...`);
      
      // 使用多個延遲時間來確保日期選擇器完全開啟
      const checkForDatePicker = (attempt = 1) => {
        console.log(`🔍 第 ${attempt} 次檢查日期選擇器...`);
        
        // 尋找日期選擇器中的「現在」按鈕
        const nowButton = findNowButton();
        
        if (nowButton) {
          console.log(`✅ 找到「現在」按鈕，準備點擊...`);
          
          // 確保按鈕可見
          nowButton.scrollIntoView({ behavior: 'smooth', block: 'center' });
          
          // 點擊按鈕
          nowButton.click();
          console.log(`✅ 已點擊「現在」按鈕`);
          
          // 如果有需要加天數，手動調整
          if (daysToAdd > 0) {
            setTimeout(() => {
              const currentValue = input.value;
              if (currentValue) {
                const date = new Date(currentValue);
                date.setDate(date.getDate() + daysToAdd);
                const newValue = date.toISOString().slice(0, 19).replace('T', ' ');
                input.value = newValue;
                input.dispatchEvent(new Event('input', { bubbles: true }));
                input.dispatchEvent(new Event('change', { bubbles: true }));
                console.log(`✅ ${fieldName} 已調整為 ${daysToAdd} 天後: ${newValue}`);
              }
            }, 300);
          }
          
          resolve();
        } else if (attempt < 5) {
          // 如果還沒找到，繼續嘗試
          console.log(`⚠️ 第 ${attempt} 次未找到「現在」按鈕，等待後重試...`);
          setTimeout(() => checkForDatePicker(attempt + 1), 300);
        } else {
          console.log(`⚠️ 多次嘗試後仍未找到「現在」按鈕，使用備用方案...`);
          // 備用方案：直接設定當前時間
          const now = new Date();
          if (daysToAdd > 0) {
            now.setDate(now.getDate() + daysToAdd);
          }
          const timeString = now.toISOString().slice(0, 19).replace('T', ' ');
          input.value = timeString;
          input.dispatchEvent(new Event('input', { bubbles: true }));
          input.dispatchEvent(new Event('change', { bubbles: true }));
          console.log(`✅ ${fieldName} 備用方案設定為: ${timeString}`);
          resolve();
        }
      };
      
      // 開始檢查
      setTimeout(() => checkForDatePicker(), 300);
    });
  }

  // 尋找「現在」按鈕的函數
  function findNowButton() {
    console.log('🔍 開始搜尋「現在」按鈕...');
    
    // 方法1: 搜尋包含「現在」文字的按鈕
    const buttons = document.querySelectorAll('button');
    for (const button of buttons) {
      if (button.textContent.includes('現在')) {
        console.log(`🔍 找到「現在」按鈕: ${button.textContent}`);
        return button;
      }
    }
    
    // 方法2: 搜尋包含「now」文字的按鈕（英文版）
    for (const button of buttons) {
      if (button.textContent.toLowerCase().includes('now')) {
        console.log(`🔍 找到「now」按鈕: ${button.textContent}`);
        return button;
      }
    }
    
    // 方法3: 搜尋特定的 CSS 類別
    const nowButtonByClass = document.querySelector('.el-picker-panel__now-btn, .el-date-picker__now-btn, .el-datetime-picker__now-btn');
    if (nowButtonByClass) {
      console.log(`🔍 通過 CSS 類別找到「現在」按鈕: ${nowButtonByClass.textContent}`);
      return nowButtonByClass;
    }
    
    // 方法4: 搜尋日期選擇器面板中的所有按鈕
    const datePanels = document.querySelectorAll('.el-picker-panel, .el-date-picker, .el-datetime-picker');
    for (const panel of datePanels) {
      const panelButtons = panel.querySelectorAll('button');
      for (const button of panelButtons) {
        const buttonText = button.textContent.trim();
        if (buttonText === '現在' || buttonText === 'Now' || buttonText.includes('現在') || buttonText.includes('now')) {
          console.log(`🔍 在日期面板中找到「現在」按鈕: ${buttonText}`);
          return button;
        }
      }
    }
    
    // 方法5: 搜尋所有可能的日期選擇器相關元素
    const allDateElements = document.querySelectorAll('[class*="picker"], [class*="date"], [class*="time"]');
    console.log(`🔍 找到 ${allDateElements.length} 個日期相關元素`);
    
    for (const element of allDateElements) {
      const buttons = element.querySelectorAll('button');
      for (const button of buttons) {
        const buttonText = button.textContent.trim();
        console.log(`🔍 檢查按鈕: "${buttonText}"`);
        if (buttonText === '現在' || buttonText === 'Now' || buttonText.includes('現在') || buttonText.includes('now')) {
          console.log(`🔍 在日期相關元素中找到「現在」按鈕: ${buttonText}`);
          return button;
        }
      }
    }
    
    console.log('❌ 未找到「現在」按鈕');
    return null;
  }



  // 為編輯視窗添加匯入 JSON 按鈕


  function printTable(data) {
    if (!Array.isArray(data) || !data.length) {
      alert('⚠️ 沒有資料可列印');
      return;
    }

    // 格式化日期
    function formatDate(dateString) {
      if (!dateString) return '無';
      const date = new Date(dateString);
      return date.toISOString().slice(0, 10);
    }

    // 格式化金額
    function formatCurrency(amount) {
      if (!amount && amount !== 0) return '無';
      return new Intl.NumberFormat('zh-TW').format(amount);
    }

    // 取得應付金額
    function getTotalAmount(payment) {
      if (!payment || typeof payment !== 'object') return null;
      return payment.TotalAmount;
    }

    // 取得得標者資訊
    function getWinnerInfo(row) {
      if (!row.WinnerID) return '無得標者';
      
      const nickName = row.NickName || '';
      const account = row.Account || '';
      
      if (nickName && account) {
        return `${nickName}(${account})`;
      } else if (nickName) {
        return nickName;
      } else if (account) {
        return account;
      } else {
        return `ID: ${row.WinnerID}`;
      }
    }

    // 準備列印資料
    const printData = data
      .sort((a, b) => b.AutoID - a.AutoID)
      .map(row => ({
        AutoID: row.AutoID || '無',
        Name: row.Name || '未命名',
        CategoryName: row.CategoryName || '無',
        DistName: row.DistName || '無',
        EndDate: formatDate(row.EndDate),
        TotalAmount: formatCurrency(getTotalAmount(row.Payment)),
        Winner: getWinnerInfo(row)
      }));

    // 建立列印頁面 HTML
    const printHTML = `
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>新北市再生家具資料表</title>
    <style>
        @media print {
            body { margin: 0; }
            table { page-break-inside: auto; }
            tr { page-break-inside: avoid; }
            .no-print { display: none; }
        }
        
        body {
            font-family: 'Microsoft JhengHei', 'Segoe UI', sans-serif;
            margin: 20px;
            font-size: 12px;
        }
        
        .header {
            text-align: center;
            margin-bottom: 20px;
        }
        
        .header h1 {
            margin: 0 0 10px 0;
            font-size: 18px;
            color: #333;
        }
        
        .header p {
            margin: 5px 0;
            color: #666;
            font-size: 11px;
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        
        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
            vertical-align: top;
        }
        
        th {
            background-color: #f5f5f5;
            font-weight: bold;
            font-size: 11px;
        }
        
        td {
            font-size: 11px;
        }
        
        .auto-id { width: 80px; }
        .name { width: 200px; }
        .category { width: 100px; }
        .district { width: 80px; }
        .end-date { width: 100px; }
        .total-amount { width: 100px; }
        .winner { width: 120px; }
        
        .no-print {
            position: fixed;
            top: 20px;
            right: 20px;
            background: #007baf;
            color: white;
            padding: 10px 15px;
            border-radius: 5px;
            cursor: pointer;
            z-index: 1000;
        }
    </style>
</head>
<body>
    <div class="no-print" onclick="window.print()">🖨️ 列印</div>
    
    <div class="header">
        <h1>新北市再生家具資料表</h1>
        <p>匯出時間：${new Date().toLocaleString('zh-TW')}</p>
        <p>資料筆數：${printData.length} 筆</p>
    </div>
    
    <table>
        <thead>
            <tr>
                <th class="auto-id">自動編號</th>
                <th class="name">家具名稱</th>
                <th class="category">類別名稱</th>
                <th class="district">行政區</th>
                <th class="end-date">結束日期</th>
                <th class="total-amount">應付金額</th>
                <th class="winner">得標者</th>
            </tr>
        </thead>
        <tbody>
            ${printData.map(row => `
                <tr>
                    <td>${row.AutoID}</td>
                    <td>${row.Name}</td>
                    <td>${row.CategoryName}</td>
                    <td>${row.DistName}</td>
                    <td>${row.EndDate}</td>
                    <td>${row.TotalAmount}</td>
                    <td>${row.Winner}</td>
                </tr>
            `).join('')}
        </tbody>
    </table>
</body>
</html>`;

    // 開啟新視窗並列印
    const printWindow = window.open('', '_blank');
    printWindow.document.write(printHTML);
    printWindow.document.close();
    
    // 等待頁面載入完成後自動列印
    printWindow.onload = () => {
      setTimeout(() => {
        printWindow.print();
      }, 500);
    };
  }

  insertButtons();
  const buttonContainer = document.querySelector('.el-button-group') || document.body;
  new MutationObserver(insertButtons).observe(buttonContainer, { childList: true, subtree: true });
  
  // 啟動表單按鈕監控
  setTimeout(() => {
    monitorFormButtons();
  }, 2000);

  // 監控表單按鈕和處理流程
  function monitorFormButtons() {
    console.log('🔍 開始監控表單按鈕和處理流程...');
    
    // 監控所有按鈕的點擊事件
    const buttons = document.querySelectorAll('button, .el-button, .btn, [type="submit"], [type="button"]');
    console.log(`🔍 找到 ${buttons.length} 個按鈕`);
    
    buttons.forEach((button, index) => {
      const buttonText = button.textContent.trim() || button.innerText.trim();
      const buttonType = button.type || 'button';
      const buttonClass = button.className;
      
      console.log(`🔍 按鈕 ${index + 1}: "${buttonText}" (type: ${buttonType}, class: ${buttonClass})`);
      
      // 監控按鈕點擊事件
      button.addEventListener('click', function(e) {
        console.log(`🖱️ 按鈕被點擊: "${buttonText}"`);
        console.log('  - 按鈕元素:', button);
        console.log('  - 事件物件:', e);
        console.log('  - 目標元素:', e.target);
        console.log('  - 當前時間:', new Date().toISOString());
        
        // 分析按鈕的父級結構
        analyzeButtonContext(button);
        
        // 如果是表單提交按鈕，分析表單狀態
        if (buttonType === 'submit' || buttonText.includes('提交') || buttonText.includes('儲存') || buttonText.includes('確定')) {
          console.log('📝 檢測到表單提交按鈕，分析表單狀態...');
          analyzeFormBeforeSubmit(button);
        }
      }, true);
    });
    
    // 監控表單提交事件
    const forms = document.querySelectorAll('form, .el-form');
    forms.forEach((form, index) => {
      console.log(`🔍 監控表單 ${index + 1}:`, form);
      
      form.addEventListener('submit', function(e) {
        console.log('📝 表單提交事件觸發');
        console.log('  - 表單元素:', form);
        console.log('  - 事件物件:', e);
        console.log('  - 提交時間:', new Date().toISOString());
        
        // 分析表單資料
        analyzeFormData(form);
        
        // 分析表單驗證狀態
        analyzeFormValidationStatus(form);
      }, true);
    });
    
    // 監控 AJAX 請求
    monitorAjaxRequests();
    
    // 監控 Vue 事件
    monitorVueEvents();
    
    // 動態監控編輯視窗中的按鈕
    monitorEditWindowButtons();
  }
  
  // 動態監控編輯視窗中的按鈕
  function monitorEditWindowButtons() {
    console.log('🔍 開始動態監控編輯視窗按鈕...');
    
    // 監控模態框的出現
    const observer = new MutationObserver((mutations) => {
      mutations.forEach((mutation) => {
        mutation.addedNodes.forEach((node) => {
          if (node.nodeType === Node.ELEMENT_NODE) {
            // 檢查是否為編輯視窗
            if (node.classList && node.classList.contains('vxe-modal--box')) {
              console.log('🔍 檢測到編輯視窗出現:', node);
              
              // 等待一下讓內容完全載入
              setTimeout(() => {
                monitorButtonsInModal(node);
              }, 500);
            }
            
            // 檢查子元素中是否有編輯視窗
            const modal = node.querySelector && node.querySelector('.vxe-modal--box');
            if (modal) {
              console.log('🔍 檢測到編輯視窗（子元素）:', modal);
              setTimeout(() => {
                monitorButtonsInModal(modal);
              }, 500);
            }
          }
        });
      });
    });
    
    observer.observe(document.body, {
      childList: true,
      subtree: true
    });
    
    // 檢查是否已經有編輯視窗存在
    const existingModal = document.querySelector('.vxe-modal--box');
    if (existingModal) {
      console.log('🔍 發現已存在的編輯視窗:', existingModal);
      monitorButtonsInModal(existingModal);
    }
  }
  
  // 監控模態框中的按鈕
  function monitorButtonsInModal(modal) {
    console.log('🔍 監控模態框中的按鈕:', modal);
    
    const buttons = modal.querySelectorAll('button, .el-button, .btn, [type="submit"], [type="button"]');
    console.log(`🔍 模態框中找到 ${buttons.length} 個按鈕`);
    
    buttons.forEach((button, index) => {
      const buttonText = button.textContent.trim() || button.innerText.trim();
      const buttonType = button.type || 'button';
      const buttonClass = button.className;
      
      console.log(`🔍 模態框按鈕 ${index + 1}: "${buttonText}" (type: ${buttonType}, class: ${buttonClass})`);
      
      // 檢查是否已經監控過這個按鈕
      if (button._monitored) {
        console.log(`  - 按鈕 "${buttonText}" 已經被監控過`);
        return;
      }
      
      // 標記為已監控
      button._monitored = true;
      
      // 監控按鈕點擊事件
      button.addEventListener('click', function(e) {
        console.log(`🖱️ 模態框按鈕被點擊: "${buttonText}"`);
        console.log('  - 按鈕元素:', button);
        console.log('  - 事件物件:', e);
        console.log('  - 目標元素:', e.target);
        console.log('  - 當前時間:', new Date().toISOString());
        
        // 分析按鈕的父級結構
        analyzeButtonContext(button);
        
        // 如果是表單提交按鈕，分析表單狀態
        if (buttonType === 'submit' || buttonText.includes('提交') || buttonText.includes('儲存') || buttonText.includes('確定')) {
          console.log('📝 檢測到模態框表單提交按鈕，分析表單狀態...');
          analyzeFormBeforeSubmit(button);
          
          // 特別分析預覽圖欄位
          analyzePreviewImageField(modal);
        }
        
        // 對於所有模態框按鈕，都進行預覽圖欄位分析
        console.log('🔍 對所有模態框按鈕進行預覽圖欄位分析...');
        analyzePreviewImageField(modal);
      }, true);
    });
    
    // 監控模態框中的表單
    const forms = modal.querySelectorAll('form, .el-form');
    forms.forEach((form, index) => {
      console.log(`🔍 監控模態框表單 ${index + 1}:`, form);
      
      form.addEventListener('submit', function(e) {
        console.log('📝 模態框表單提交事件觸發');
        console.log('  - 表單元素:', form);
        console.log('  - 事件物件:', e);
        console.log('  - 提交時間:', new Date().toISOString());
        
        // 分析表單資料
        analyzeFormData(form);
        
        // 分析表單驗證狀態
        analyzeFormValidationStatus(form);
      }, true);
    });
  }
  
  // 特別分析預覽圖欄位
  function analyzePreviewImageField(modal) {
    console.log('🔍 特別分析預覽圖欄位...');
    
    const formItems = modal.querySelectorAll('.el-form-item');
    let previewImageItem = null;
    
    formItems.forEach((item, index) => {
      const label = item.querySelector('.el-form-item__label');
      if (label && label.textContent.trim() === '預覽圖') {
        previewImageItem = item;
        console.log(`🔍 找到預覽圖欄位 ${index + 1}:`, item);
        
        // 詳細分析預覽圖欄位
        const input = item.querySelector('input[type="file"]');
        const error = item.querySelector('.el-form-item__error');
        const uploadComponent = item.querySelector('.el-upload');
        
        console.log('  - 預覽圖欄位詳細分析:');
        console.log('    - Form Item:', item);
        console.log('    - File Input:', input);
        console.log('    - Error Element:', error);
        console.log('    - Upload Component:', uploadComponent);
        
        if (input) {
          console.log('    - File Input 屬性:');
          console.log('      - name:', input.name);
          console.log('      - accept:', input.accept);
          console.log('      - required:', input.required);
          console.log('      - multiple:', input.multiple);
          console.log('      - files.length:', input.files ? input.files.length : 0);
          console.log('      - value:', input.value);
        }
        
        if (uploadComponent) {
          console.log('    - Upload Component 分析:');
          console.log('      - classList:', uploadComponent.classList.toString());
          
          const uploadList = uploadComponent.querySelector('.el-upload-list');
          if (uploadList) {
            console.log('      - Upload List:', uploadList);
            console.log('      - Upload List Items:', uploadList.children.length);
          }
          
          const uploadInput = uploadComponent.querySelector('.el-upload__input');
          if (uploadInput) {
            console.log('      - Upload Input:', uploadInput);
            console.log('      - Upload Input files:', uploadInput.files ? uploadInput.files.length : 0);
          }
        }
        
        if (error) {
          console.log('    - 驗證錯誤:', error.textContent);
        }
      }
    });
    
    if (!previewImageItem) {
      console.log('  - 未找到預覽圖欄位');
    }
  }

  // 分析按鈕的上下文
  function analyzeButtonContext(button) {
    console.log('🔍 分析按鈕上下文...');
    
    // 尋找按鈕所在的表單
    const form = button.closest('form, .el-form');
    if (form) {
      console.log('  - 所屬表單:', form);
      console.log('  - 表單 action:', form.action);
      console.log('  - 表單 method:', form.method);
    }
    
    // 尋找按鈕所在的模態框
    const modal = button.closest('.vxe-modal, .el-dialog, .modal');
    if (modal) {
      console.log('  - 所屬模態框:', modal);
      console.log('  - 模態框標題:', modal.querySelector('.vxe-modal--header-title, .el-dialog__title, .modal-title')?.textContent);
    }
    
    // 分析按鈕的 Vue 屬性
    const vueAttrs = ['v-on:click', 'v-on:submit', '@click', '@submit', 'data-v-on'];
    vueAttrs.forEach(attr => {
      if (button.hasAttribute(attr)) {
        console.log(`  - Vue 事件屬性 ${attr}:`, button.getAttribute(attr));
      }
    });
    
    // 分析按鈕的 data 屬性
    const dataAttrs = Array.from(button.attributes).filter(attr => attr.name.startsWith('data-'));
    if (dataAttrs.length > 0) {
      console.log('  - Data 屬性:');
      dataAttrs.forEach(attr => {
        console.log(`    ${attr.name}: ${attr.value}`);
      });
    }
  }
  
  // 分析表單提交前的狀態
  function analyzeFormBeforeSubmit(button) {
    console.log('🔍 分析表單提交前狀態...');
    
    const form = button.closest('form, .el-form');
    if (!form) {
      console.log('  - 未找到所屬表單');
      return;
    }
    
    // 分析所有表單欄位
    const formItems = form.querySelectorAll('.el-form-item');
    console.log(`  - 表單欄位數量: ${formItems.length}`);
    
    formItems.forEach((item, index) => {
      const label = item.querySelector('.el-form-item__label');
      const input = item.querySelector('input, textarea, select');
      const error = item.querySelector('.el-form-item__error');
      
      console.log(`  - 欄位 ${index + 1}:`);
      console.log(`    標籤: ${label ? label.textContent.trim() : '無標籤'}`);
      console.log(`    輸入元素: ${input ? input.tagName + (input.name ? `[name="${input.name}"]` : '') : '無輸入元素'}`);
      console.log(`    驗證狀態: ${item.classList.contains('is-error') ? '錯誤' : item.classList.contains('is-success') ? '成功' : '正常'}`);
      console.log(`    錯誤訊息: ${error ? error.textContent : '無錯誤'}`);
      
      // 如果是檔案輸入，分析檔案狀態
      if (input && input.type === 'file') {
        console.log(`    檔案數量: ${input.files ? input.files.length : 0}`);
        if (input.files && input.files.length > 0) {
          Array.from(input.files).forEach((file, fileIndex) => {
            console.log(`      檔案 ${fileIndex + 1}: ${file.name} (${file.size} bytes, ${file.type})`);
          });
        }
      }
    });
    
    // 分析表單驗證規則
    const formRules = form.getAttribute('data-rules') || form.getAttribute('rules');
    if (formRules) {
      console.log('  - 表單驗證規則:', formRules);
    }
  }
  
  // 分析表單資料
  function analyzeFormData(form) {
    console.log('🔍 分析表單資料...');
    
    // 收集所有表單資料
    const formData = new FormData(form);
    console.log('  - FormData 內容:');
    for (let [key, value] of formData.entries()) {
      if (value instanceof File) {
        console.log(`    ${key}: File(${value.name}, ${value.size} bytes, ${value.type})`);
      } else {
        console.log(`    ${key}: ${value}`);
      }
    }
    
    // 分析所有輸入欄位的值
    const inputs = form.querySelectorAll('input, textarea, select');
    console.log('  - 輸入欄位值:');
    inputs.forEach(input => {
      if (input.type === 'file') {
        console.log(`    ${input.name || input.id}: ${input.files ? input.files.length : 0} 個檔案`);
      } else {
        console.log(`    ${input.name || input.id}: ${input.value}`);
      }
    });
  }
  
  // 分析表單驗證狀態
  function analyzeFormValidationStatus(form) {
    console.log('🔍 分析表單驗證狀態...');
    
    const errorItems = form.querySelectorAll('.is-error, .el-form-item__error');
    console.log(`  - 驗證錯誤數量: ${errorItems.length}`);
    
    errorItems.forEach((error, index) => {
      const formItem = error.closest('.el-form-item');
      const label = formItem ? formItem.querySelector('.el-form-item__label') : null;
      console.log(`  - 錯誤 ${index + 1}: ${label ? label.textContent : '未知欄位'} - ${error.textContent}`);
    });
    
    const requiredItems = form.querySelectorAll('.is-required, [required]');
    console.log(`  - 必填欄位數量: ${requiredItems.length}`);
    
    requiredItems.forEach((item, index) => {
      const label = item.querySelector('.el-form-item__label');
      const input = item.querySelector('input, textarea, select');
      const hasValue = input && (
        (input.type === 'file' && input.files && input.files.length > 0) ||
        (input.type !== 'file' && input.value.trim() !== '')
      );
      console.log(`  - 必填欄位 ${index + 1}: ${label ? label.textContent : '未知'} - ${hasValue ? '已填寫' : '未填寫'}`);
    });
  }
  
  // 監控 AJAX 請求
  function monitorAjaxRequests() {
    console.log('🔍 開始監控 AJAX 請求...');
    
    // 監控 XMLHttpRequest
    const originalXHROpen = XMLHttpRequest.prototype.open;
    const originalXHRSend = XMLHttpRequest.prototype.send;
    
    XMLHttpRequest.prototype.open = function(method, url, async, user, password) {
      console.log(`🌐 XHR 請求開啟: ${method} ${url}`);
      console.log('  - 請求方法:', method);
      console.log('  - 請求 URL:', url);
      console.log('  - 是否異步:', async);
      
      this._requestInfo = { method, url, async };
      return originalXHROpen.call(this, method, url, async, user, password);
    };
    
    XMLHttpRequest.prototype.send = function(data) {
      console.log(`🌐 XHR 請求發送: ${this._requestInfo.method} ${this._requestInfo.url}`);
      if (data) {
        console.log('  - 請求資料:', data);
      }
      
      this.addEventListener('load', function() {
        console.log(`🌐 XHR 請求完成: ${this._requestInfo.method} ${this._requestInfo.url}`);
        console.log('  - 狀態碼:', this.status);
        console.log('  - 回應標頭:', this.getAllResponseHeaders());
        console.log('  - 回應內容:', this.responseText.substring(0, 500) + (this.responseText.length > 500 ? '...' : ''));
      });
      
      this.addEventListener('error', function() {
        console.log(`❌ XHR 請求錯誤: ${this._requestInfo.method} ${this._requestInfo.url}`);
      });
      
      return originalXHRSend.call(this, data);
    };
    
    // 監控 Fetch API
    const originalFetch = window.fetch;
    window.fetch = function(url, options = {}) {
      console.log(`🌐 Fetch 請求: ${options.method || 'GET'} ${url}`);
      console.log('  - 請求選項:', options);
      
      return originalFetch.call(this, url, options).then(response => {
        console.log(`🌐 Fetch 請求完成: ${options.method || 'GET'} ${url}`);
        console.log('  - 狀態碼:', response.status);
        console.log('  - 狀態文字:', response.statusText);
        
        // 複製回應以便讀取內容
        const responseClone = response.clone();
        responseClone.text().then(text => {
          console.log('  - 回應內容:', text.substring(0, 500) + (text.length > 500 ? '...' : ''));
        });
        
        return response;
      }).catch(error => {
        console.log(`❌ Fetch 請求錯誤: ${options.method || 'GET'} ${url}`, error);
        throw error;
      });
    };
  }
  
  // 監控 Vue 事件
  function monitorVueEvents() {
    console.log('🔍 開始監控 Vue 事件...');
    
    // 監控 Vue 的 $emit 事件
    if (window.Vue) {
      const originalEmit = window.Vue.prototype.$emit;
      window.Vue.prototype.$emit = function(event, ...args) {
        console.log(`🎯 Vue 事件發射: ${event}`, args);
        return originalEmit.call(this, event, ...args);
      };
    }
    
    // 監控 Element UI 的事件
    const elementEvents = ['click', 'submit', 'change', 'input', 'blur', 'focus'];
    elementEvents.forEach(eventType => {
      document.addEventListener(eventType, function(e) {
        // 只記錄來自 Element UI 組件的事件
        if (e.target.closest('.el-form, .el-button, .el-upload, .el-input')) {
          console.log(`🎯 Element UI 事件: ${eventType}`, e.target);
        }
      }, true);
    });
  }

  async function directSubmitToAPI(jsonData) {
    console.log('�� 開始直接 API 送出...');
    try {
      // 準備 API payload
      const payload = {
        CategoryID: jsonData.CategoryID || 13,
        Name: jsonData.Name || '',
        Description: jsonData.Description || '',
        InitPrice: jsonData.InitPrice || '0',
        OriginPrice: jsonData.OriginPrice || '0',
        MinAddPrice: jsonData.MinAddPrice || 10,
        StartDate: jsonData.StartDate || new Date().toISOString().slice(0, 19).replace('T', ' '),
        EndDate: jsonData.EndDate || new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().slice(0, 19).replace('T', ' '),
        DistID: jsonData.DistID || '231',
        DeliveryAddress: jsonData.DeliveryAddress || '',
        Length: jsonData.Length || '0',
        Width: jsonData.Width || '0',
        Height: jsonData.Height || '0',
        Photos: []
      };
      // 處理圖片
      if (jsonData.Photos && Array.isArray(jsonData.Photos) && jsonData.Photos.length > 0) {
        const hasBase64Images = jsonData.Photos.some(photo => photo.Photo && photo.Photo.startsWith('data:image'));
        if (hasBase64Images) {
          const uploadedPhotos = await uploadImagesWithCorrectAPI(jsonData.Photos);
          payload.Photos = uploadedPhotos.map(photo => ({ Photo: photo.uploadedUrl }));
        } else {
          payload.Photos = jsonData.Photos;
        }
      }
      console.log('📡 送出 API payload:', payload);
      // 送出 API 請求
      const response = await fetch('/BidMgr/api/Product/AddProduct', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
      const result = await response.json();
      console.log('✅ API 送出成功:', result);
      // 觸發查詢按鈕刷新表格
      setTimeout(() => {
        const queryBtn = Array.from(document.querySelectorAll('button.el-button')).find(b => /查\s*詢/.test(b.textContent));
        if (queryBtn) {
          try {
            if (queryBtn.__vue__ && queryBtn.__vue__.$emit) {
              queryBtn.__vue__.$emit('click');
            } else {
              const clickEvent = new MouseEvent('click', { bubbles: true, cancelable: true, view: window });
              queryBtn.dispatchEvent(clickEvent);
            }
            console.log('✅ 查詢按鈕觸發成功，表格應該會重新載入');
          } catch (error) {
            console.error('❌ 觸發查詢按鈕時發生錯誤:', error);
          }
        } else {
          console.error('❌ 查詢按鈕未找到，無法重新載入表格');
        }
      }, 2000);
      return result;
    } catch (error) {
      console.error('❌ API 送出失敗:', error);
      alert(`❌ API 送出失敗: ${error.message}`);
      throw error;
    }
  }

  async function uploadImagesWithCorrectAPI(photos) {
    const uploaded = [];
    for (let i = 0; i < photos.length; i++) {
      const photo = photos[i];
      if (photo.Photo && photo.Photo.startsWith('data:image')) {
        const file = base64ToFile(photo.Photo, `image_${i + 1}.jpg`);
        const result = await uploadImage(file);
        uploaded.push({ ...photo, uploadedUrl: result.FilePath || result });
      } else if (photo.Photo) {
        uploaded.push(photo);
      }
    }
    return uploaded;
  }

})();