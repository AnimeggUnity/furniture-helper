<?php
$config_file = __DIR__ . '/config.php';
$wizard_file = __FILE__;

// Function to safely delete the wizard file
function deleteWizardFile($file_path) {
    if (file_exists($file_path)) {
        unlink($file_path);
    }
}

// If config.php exists, setup is already done, delete wizard and redirect
if (file_exists($config_file)) {
    deleteWizardFile($wizard_file);
    header('Location: webhook.php'); // Redirect to main application
    exit;
}

$message = '';
$error = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $line_access_token = trim($_POST['line_access_token'] ?? '');
    $line_channel_secret = trim($_POST['line_channel_secret'] ?? '');

    if (empty($line_access_token) || empty($line_channel_secret)) {
        $message = 'LINE Access Token 和 LINE Channel Secret 都是必填項。';
        $error = true;
    } else {
        $config_content = "<?php
";
        $config_content .= "// =================================================================
";
        $config_content .= "// 家具管理系統 - 自動產生的設定檔
";
        $config_content .= "// 建立時間：" . date('Y-m-d H:i:s') . "
";
        $config_content .= "// =================================================================

";
        $config_content .= "// 2. LINE Bot 設定
";
        $config_content .= "define('LINE_ACCESS_TOKEN', '" . addslashes($line_access_token) . "');
";
        $config_content .= "define('LINE_CHANNEL_SECRET', '" . addslashes($line_channel_secret) . "');

";
        $config_content .= "?>";

        if (file_put_contents($config_file, $config_content) !== false) {
            $protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http";
            $host = $_SERVER['HTTP_HOST'];
            $script_name = $_SERVER['SCRIPT_NAME'];
            $base_path = dirname($script_name);
            $webhook_url = $protocol . "://" . $host . $base_path . "/webhook.php";

            $message = '設定檔已成功建立！請將以下 URL 複製到您的 LINE Developers 後台 Webhook URL 設定中：<br><br>' . htmlspecialchars($webhook_url) . '<br><br>精靈將自動刪除並跳轉。';
            // Delete wizard file after successful setup
            deleteWizardFile($wizard_file);
            header('Refresh: 10; URL=files.php'); // Redirect after 10 seconds
        } else {
            $message = '無法寫入設定檔，請檢查目錄權限。';
            $error = true;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="zh-TW">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>環境設定精靈</title>
    <style>
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            max-width: 600px;
            margin: 50px auto;
            padding: 20px;
            background-color: #f5f5f5;
            color: #333;
            line-height: 1.6;
        }
        .container {
            background: white;
            border-radius: 10px;
            padding: 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        h1 {
            text-align: center;
            color: #007bff;
            margin-bottom: 30px;
        }
        .form-group {
            margin-bottom: 20px;
        }
        label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
        }
        input[type="text"] {
            width: 100%;
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 5px;
            box-sizing: border-box;
            font-size: 16px;
        }
        button {
            background-color: #007bff;
            color: white;
            padding: 12px 25px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 18px;
            width: 100%;
            transition: background-color 0.3s ease;
        }
        button:hover {
            background-color: #0056b3;
        }
        .message {
            margin-top: 20px;
            padding: 15px;
            border-radius: 5px;
            font-weight: bold;
            text-align: center;
        }
        .message.success {
            background-color: #d4edda;
            color: #155724;
            border-color: #c3e6cb;
        }
        .message.error {
            background-color: #f8d7da;
            color: #721c24;
            border-color: #f5c6cb;
        }
        .note {
            margin-top: 25px;
            padding: 15px;
            background-color: #e9ecef;
            border-left: 5px solid #007bff;
            border-radius: 5px;
            font-size: 14px;
            color: #555;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>✨ 環境設定精靈</h1>
        <?php if ($message): ?>
            <div class="message <?php echo $error ? 'error' : 'success'; ?>">
                <?php echo $message; ?>
            </div>
        <?php endif; ?>
        <?php if (!$message || $error): // Only show form if no success message or if there's an error ?>
            <form method="POST">
                <div class="form-group">
                    <label for="line_access_token">LINE Access Token:</label>
                    <input type="text" id="line_access_token" name="line_access_token" required>
                </div>
                <div class="form-group">
                    <label for="line_channel_secret">LINE Channel Secret:</label>
                    <input type="text" id="line_channel_secret" name="line_channel_secret" required>
                </div>
                <button type="submit">儲存設定</button>
            </form>
            <div class="note">
                <p><strong>說明：</strong></p>
                <p>請從您的 LINE Developers 後台獲取 LINE Bot 的 "Channel Access Token (Long-lived)" 和 "Channel Secret"。</p>
                <p>完成設定後，此精靈檔案將自動刪除，並跳轉到主應用程式。</p>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>
