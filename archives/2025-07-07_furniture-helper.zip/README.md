# 家具助手擴充功能

## 功能概述
這是一個專為新北市再生家具系統設計的 Chrome 擴充功能，提供多種實用功能來提升工作效率。

## 主要功能

### 1. 📈 年度統計
- 顯示年度和月份的資料統計
- 自動計算各時期的資料筆數
- 以彈出視窗形式呈現統計結果

### 2. 📥 資料匯出
- **輕量匯出**：匯出基本欄位（編號、名稱、行政區、建立日期）
- **全部匯出**：匯出完整資料包含所有欄位
- 支援 CSV 格式下載

### 3. 📂 資料面板
- 側邊面板顯示所有家具資料
- 支援 AutoID 搜尋功能
- 可預覽圖片和下載 JSON 檔案
- 包含圖片下載功能

### 4. 🖨️ 列印表格
- 生成格式化的列印頁面
- 包含完整的家具資訊
- 支援得標者資訊顯示

### 5. 📥 JSON 匯入功能（新增）
- 在編輯表單中匯入 JSON 檔案
- 自動填充表單欄位
- 支援 Element UI Select 元件的模擬點擊
- 完整的表單驗證功能

## JSON 匯入功能詳細說明

### 功能特點
- **自動填充**：根據 JSON 資料自動填充表單欄位
- **模擬點擊**：正確處理 Element UI Select 元件的類別和行政區欄位
- **事件觸發**：確保 Vue 組件狀態正確更新
- **驗證支援**：觸發表單驗證確保資料正確

### 使用方式
1. 點擊「新增」按鈕開啟編輯視窗
2. 在編輯視窗標題列會出現「匯入 JSON」按鈕
3. 點擊按鈕選擇 JSON 檔案
4. 系統會自動填充表單欄位

### JSON 格式要求
```json
{
  "AutoID": 2047,
  "Name": "E27 夾式筒燈 - 6",
  "CategoryName": "燈具、燈飾",
  "DistName": "新店區",
  "CreateDate": "2025-04-19T18:17:15.643",
  "Description": "產品描述...",
  "Length": 0,
  "Width": 0,
  "Height": 0,
  "DeliveryAddress": "新北市新店區薏仁坑路自強巷2-3號",
  "InitPrice": 20,
  "OriginPrice": 20,
  "Photos": [...]
}
```

### 支援的欄位映射
| 表單標籤 | JSON 欄位 | 說明 |
|---------|----------|------|
| 品名 | Name | 家具名稱 |
| 類別 | CategoryName | 家具類別 |
| 行政區 | DistName | 行政區名稱 |
| 產品描述 | Description | 產品詳細描述 |
| 長 | Length | 長度 |
| 寬 | Width | 寬度 |
| 高 | Height | 高度 |
| 交貨地點 | DeliveryAddress | 交貨地址 |
| 起標價格 | InitPrice | 起標價格 |
| 原價 | OriginPrice | 原價 |

### 技術實現
- **forceVueUpdate**：強制更新 Vue 組件狀態
- **validateFormData**：驗證表單資料完整性
- **fillForm**：核心填充邏輯，支援 Element UI Select 元件
- **insertImportButton**：動態插入匯入按鈕

### 模擬點擊流程
1. 找到 Element UI Select 元件
2. 找到下拉選單和選項
3. 點擊輸入框開啟下拉選單
4. 延遲 100ms 確保下拉選單完全開啟
5. 點擊匹配的選項
6. 觸發必要的事件

## 安裝方式
1. 下載擴充功能檔案
2. 開啟 Chrome 擴充功能管理頁面
3. 啟用開發者模式
4. 載入未封裝項目
5. 選擇擴充功能資料夾

## 使用注意事項
- 確保 JSON 檔案包含必要的 AutoID 和 Name 欄位
- 模擬點擊功能是解決 Element UI Select 驗證問題的關鍵
- 延遲時間（100ms）可能需要根據網路速度調整
- 建議在匯入前先備份現有資料

## 開發者功能
- 欄位分析：`window.postMessage({ source: 'run-vue-debug-fields' }, '*')`
- Payment 物件分析：`window.postMessage({ source: 'run-vue-payment-analysis' }, '*')`
- WinnerID 欄位分析：`window.postMessage({ source: 'run-vue-winner-analysis' }, '*')`

## 技術架構
- **content.js**：主要功能實現，包含 UI 操作和資料處理
- **inject.js**：Vue 資料存取和事件處理
- **manifest.json**：擴充功能配置檔案

## 更新日誌
- 2025-01-XX：新增 JSON 匯入功能
- 2025-01-XX：優化 Element UI Select 元件處理
- 2025-01-XX：增強表單驗證功能 