<?php
// 添加 CORS 標頭，允許跨域請求
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Accept');

// 處理 OPTIONS 預檢請求
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// 設定刪除密碼（建議修改為更安全的密碼）
$DELETE_PASSWORD = 'admin123';



// 處理刪除請求
if (isset($_POST['action']) && $_POST['action'] === 'delete' && isset($_POST['file']) && isset($_POST['password'])) {
    $filename = $_POST['file'];
    $password = $_POST['password'];
    $filepath = __DIR__ . "/packaged_data/" . $filename;
    
    // 驗證密碼
    if ($password !== $DELETE_PASSWORD) {
        http_response_code(403);
        echo json_encode(['success' => false, 'message' => '密碼錯誤']);
        exit;
    }
    
    // 安全性檢查
    if (strpos($filename, '..') !== false || !file_exists($filepath)) {
        http_response_code(404);
        echo json_encode(['success' => false, 'message' => '檔案不存在']);
        exit;
    }
    
    // 執行刪除
    if (unlink($filepath)) {
        echo json_encode(['success' => true, 'message' => '檔案刪除成功']);
    } else {
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => '檔案刪除失敗']);
    }
    exit;
}

// =================================================================
// 家具資料檔案列表與下載頁面
// 顯示最近 30 筆 JSON 檔案，支援直接下載
// =================================================================

// 檢查設定檔是否存在，如果不存在則導向設定精靈
if (!file_exists(__DIR__ . '/config.php')) {
    header('Location: setup_wizard.php');
    exit;
}

// 設定時區
date_default_timezone_set('Asia/Taipei');

// 處理下載請求
if (isset($_GET['action']) && $_GET['action'] === 'download' && isset($_GET['file'])) {
    $filename = $_GET['file'];
    $filepath = __DIR__ . "/packaged_data/" . $filename;
    
    // 安全性檢查
    if (strpos($filename, '..') !== false || !file_exists($filepath)) {
        http_response_code(404);
        exit('檔案不存在');
    }
    
    // 嘗試用標題作為下載檔名
    $downloadName = $filename;
    $jsonContent = @file_get_contents($filepath);
    if ($jsonContent) {
        $jsonData = json_decode($jsonContent, true);
        if ($jsonData && isset($jsonData['PackageInfo']['Title'])) {
            $title = trim($jsonData['PackageInfo']['Title']);
            if ($title !== '') {
                // 避免特殊字元
                $titleForDownload = preg_replace('/[^a-zA-Z0-9\x{4e00}-\x{9fa5}]/u', '', $title);
                if ($titleForDownload === '') $titleForDownload = 'furniture';
                $downloadName = $titleForDownload . '.json';
            }
        }
    }
    
    // 設定下載標頭
    header('Content-Type: application/json');
    header('Content-Disposition: attachment; filename="' . $downloadName . '"');
    header('Content-Length: ' . filesize($filepath));
    
    // 輸出檔案內容
    readfile($filepath);
    exit;
}

// 取得檔案列表
$packagedDir = __DIR__ . "/packaged_data";
$files = [];

if (is_dir($packagedDir)) {
    $fileList = glob($packagedDir . "/*.json");
    
    foreach ($fileList as $filepath) {
        $filename = basename($filepath);
        $fileTime = filemtime($filepath);
        $fileSize = filesize($filepath);
        
        // 嘗試從 JSON 檔案中讀取標題
        $title = '未命名商品';
        $price = '未設定價格';
        
        try {
            $jsonContent = file_get_contents($filepath);
            $jsonData = json_decode($jsonContent, true);
            
            if ($jsonData && isset($jsonData['PackageInfo']['Title'])) {
                $title = $jsonData['PackageInfo']['Title'];
            }
            if ($jsonData && isset($jsonData['PackageInfo']['Price'])) {
                $price = $jsonData['PackageInfo']['Price'] . ' 元';
            }
        } catch (Exception $e) {
            // 如果讀取失敗，使用檔名作為標題
            $title = pathinfo($filename, PATHINFO_FILENAME);
        }
        
        $files[] = [
            'filename' => $filename,
            'filepath' => $filepath,
            'time' => $fileTime,
            'size' => $fileSize,
            'date' => date('Y-m-d H:i:s', $fileTime),
            'title' => $title,
            'price' => $price
        ];
    }
    
    // 按時間排序（最新的在前面）
    usort($files, function($a, $b) {
        return $b['time'] - $a['time'];
    });
    
    // 只取最近 30 筆
    $files = array_slice($files, 0, 30);
}

// 處理 JSON API 請求
if (isset($_GET['format']) && $_GET['format'] === 'json') {
    // 告訴瀏覽器回傳的是 JSON 資料
    header('Content-Type: application/json');
    
    // 建立完整的下載 URL 的基礎部分
    $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? "https" : "http";
    $host = $_SERVER['HTTP_HOST'];
    // 這裡需要根據你的實際部署路徑調整
    // 假設 files.php 在 /webhook_standalone_test/files.php
    $base_url_for_download = $protocol . '://' . $host . dirname($_SERVER['PHP_SELF']) . '/files.php'; 

    $api_files = [];
    foreach ($files as $file) {
        $api_files[] = [
            'title' => $file['title'],
            'price' => $file['price'],
            'date' => $file['date'],
            // 構建每個檔案的下載連結
            'download_url' => $base_url_for_download . '?action=download&file=' . urlencode($file['filename'])
        ];
    }

    // 直接輸出 JSON 並結束腳本
    echo json_encode($api_files, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    exit;
}
?>
<?php if (!isset($_GET['format']) || $_GET['format'] !== 'json'): ?>
<script>const DELETE_PASSWORD = '<?= addslashes($DELETE_PASSWORD) ?>';</script>
<?php endif; ?>
<!DOCTYPE html>
<html lang="zh-TW">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>家具資料檔案</title>
    <style>
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
            background-color: #f5f5f5;
        }
        .container {
            background: white;
            border-radius: 10px;
            padding: 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        h1 {
            color: #333;
            text-align: center;
            margin-bottom: 30px;
        }
        .file-item {
            border: 1px solid #e0e0e0;
            border-radius: 8px;
            padding: 15px;
            margin-bottom: 15px;
            background: #fafafa;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .file-info {
            display: flex;
            align-items: center;
            gap: 20px;
            flex: 1;
        }
        .file-title {
            font-weight: bold;
            color: #333;
            font-size: 16px;
            min-width: 200px;
        }
        .file-date {
            color: #666;
            font-size: 14px;
            min-width: 150px;
        }
        .file-size {
            color: #888;
            font-size: 14px;
            min-width: 80px;
        }
        .file-price {
            color: #28a745;
            font-size: 14px;
            min-width: 100px;
            font-weight: bold;
        }
        .download-btn {
            background: #007bff;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 14px;
            text-decoration: none;
            display: inline-block;
            white-space: nowrap;
        }
        .download-btn:hover {
            background: #0056b3;
        }
        .delete-btn {
            background: #dc3545;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 14px;
            text-decoration: none;
            display: inline-block;
            white-space: nowrap;
            margin-left: 10px;
        }
        .delete-btn:hover {
            background: #c82333;
        }
        .delete-btn:disabled {
            background: #6c757d;
            cursor: not-allowed;
        }
        .no-files {
            text-align: center;
            color: #666;
            padding: 40px;
        }
        .header-info {
            text-align: center;
            color: #666;
            margin-bottom: 30px;
            font-size: 14px;
        }
        .login-section {
            text-align: center;
            margin-bottom: 20px;
            padding: 15px;
            background: #f8f9fa;
            border-radius: 8px;
            border: 1px solid #e9ecef;
        }
        .login-input {
            padding: 8px 12px;
            border: 1px solid #ddd;
            border-radius: 4px;
            margin-right: 10px;
            font-size: 14px;
            width: 150px;
        }
        .login-btn {
            background: #28a745;
            color: white;
            border: none;
            padding: 8px 16px;
            border-radius: 4px;
            cursor: pointer;
            font-size: 14px;
        }
        .login-btn:hover {
            background: #218838;
        }
        .logout-btn {
            background: #6c757d;
            color: white;
            border: none;
            padding: 8px 16px;
            border-radius: 4px;
            cursor: pointer;
            font-size: 14px;
        }
        .logout-btn:hover {
            background: #545b62;
        }
        .delete-btn {
            display: none; /* 預設隱藏 */
        }
        .delete-btn.show {
            display: inline-block; /* 登入後顯示 */
        }

    </style>
</head>
<body>
    <div class="container">
        <h1>📁 家具資料檔案</h1>
        
        <div class="header-info">
            📋 最近檔案 (最多顯示 30 筆)<br>
            💡 點擊「下載」按鈕即可下載 JSON 檔案
        </div>

        <!-- 登入區域 -->
        <div class="login-section">
            <div id="loginForm">
                <input type="password" id="loginPassword" class="login-input" placeholder="輸入刪除密碼" />
                <button class="login-btn" onclick="login()">🔐 登入</button>
            </div>
            <div id="logoutForm" style="display: none;">
                <span style="color: #28a745; font-weight: bold;">✅ 已登入</span>
                <button class="logout-btn" onclick="logout()">🚪 登出</button>
            </div>
        </div>
        
        <?php if (empty($files)): ?>
            <div class="no-files">
                📭 目前沒有可下載的檔案<br>
                <small>請先使用 LINE Bot 建立家具資料</small>
            </div>
        <?php else: ?>
            <?php foreach ($files as $file): ?>
                <div class="file-item">
                    <div class="file-info">
                        <div class="file-title">📦 <?= htmlspecialchars($file['title']) ?></div>
                        <div class="file-date">🕒 <?= $file['date'] ?></div>
                        <div class="file-size">📏 <?= number_format($file['size'] / 1024, 1) ?> KB</div>
                        <div class="file-price">💰 <?= htmlspecialchars($file['price']) ?></div>
                    </div>
                    <a href="?action=download&file=<?= urlencode($file['filename']) ?>" 
                       class="download-btn">
                        ⬇️ 下載
                    </a>
                    <button class="delete-btn" onclick="deleteFile('<?= htmlspecialchars($file['filename']) ?>', '<?= htmlspecialchars($file['title']) ?>')">
                        🗑️ 刪除
                    </button>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>



    <script>
        // 檢查登入狀態
        function checkLoginStatus() {
            const isLoggedIn = getCookie('delete_auth') === 'true';
            if (isLoggedIn) {
                showLoggedInState();
            } else {
                showLoggedOutState();
            }
        }

        // 登入
        function login() {
            const password = document.getElementById('loginPassword').value;
            if (!password) {
                return;
            }

            // 驗證密碼
            if (password === DELETE_PASSWORD) { // 使用 PHP 傳遞的密碼
                setCookie('delete_auth', 'true', 24); // 24小時過期
                showLoggedInState();
                document.getElementById('loginPassword').value = '';
            }
        }

        // 登出
        function logout() {
            setCookie('delete_auth', '', -1); // 刪除 cookie
            showLoggedOutState();
        }

        // 顯示已登入狀態
        function showLoggedInState() {
            document.getElementById('loginForm').style.display = 'none';
            document.getElementById('logoutForm').style.display = 'block';
            // 顯示所有刪除按鈕
            document.querySelectorAll('.delete-btn').forEach(btn => {
                btn.classList.add('show');
            });
        }

        // 顯示未登入狀態
        function showLoggedOutState() {
            document.getElementById('loginForm').style.display = 'block';
            document.getElementById('logoutForm').style.display = 'none';
            // 隱藏所有刪除按鈕
            document.querySelectorAll('.delete-btn').forEach(btn => {
                btn.classList.remove('show');
            });
        }

        // 刪除檔案
        function deleteFile(filename, title) {
            console.log('開始刪除檔案:', filename);
            
            // 發送刪除請求
            const formData = new FormData();
            formData.append('action', 'delete');
            formData.append('file', filename);
            formData.append('password', DELETE_PASSWORD); // 使用 PHP 傳遞的密碼

            fetch(window.location.href, {
                method: 'POST',
                body: formData
            })
            .then(response => {
                console.log('收到回應:', response.status);
                return response.json();
            })
            .then(data => {
                console.log('刪除結果:', data);
                if (data.success) {
                    console.log('刪除成功，重新載入頁面');
                    // 重新載入頁面
                    window.location.reload();
                } else {
                    console.log('刪除失敗:', data.message);
                    // 如果密碼錯誤，可能是 cookie 過期，重新登入
                    if (data.message.includes('密碼錯誤')) {
                        logout();
                    }
                }
            })
            .catch(error => {
                console.error('刪除失敗:', error);
            });
        }

        // Cookie 操作函數
        function setCookie(name, value, hours) {
            let expires = '';
            if (hours) {
                const date = new Date();
                date.setTime(date.getTime() + (hours * 60 * 60 * 1000));
                expires = '; expires=' + date.toUTCString();
            }
            document.cookie = name + '=' + value + expires + '; path=/';
        }

        function getCookie(name) {
            const nameEQ = name + '=';
            const ca = document.cookie.split(';');
            for (let i = 0; i < ca.length; i++) {
                let c = ca[i];
                while (c.charAt(0) === ' ') c = c.substring(1, c.length);
                if (c.indexOf(nameEQ) === 0) return c.substring(nameEQ.length, c.length);
            }
            return null;
        }

        // 按 Enter 鍵登入
        document.getElementById('loginPassword').addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                login();
            }
        });

        // 頁面載入時檢查登入狀態
        document.addEventListener('DOMContentLoaded', function() {
            checkLoginStatus();
        });
    </script>
</body>
</html> 