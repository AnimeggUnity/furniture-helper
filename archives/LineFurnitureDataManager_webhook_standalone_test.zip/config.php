<?php
// =================================================================
// 家具管理系統 - 自動產生的設定檔
// 建立時間：2025-07-09 23:52:40
// =================================================================

// 2. LINE Bot 設定
define('LINE_ACCESS_TOKEN', 'GKare+LM3I5dvz116CqQX1MY6CzMQiJk0FV91fNl5k83dTO8OXzykPw0LaexCQvZ32qgkqnKfrg4kq68rr8J7wnY2Wr8mU5c+M2umhHpwCcA8vn+9pWxv8PNJAP1JXSYsjJ2Qptc59tYmL5lmxjrXgdB04t89/1O/w1cDnyilFU=');
define('LINE_CHANNEL_SECRET', '7e5edddee3d221f0d85d996aea358259');

?>