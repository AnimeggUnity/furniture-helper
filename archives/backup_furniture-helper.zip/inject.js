window.addEventListener('message', event => {
  if (event.source !== window) return;
  const source = event.data?.source;
  const table = document.querySelector('.vxe-table');
  let vue = table?.__vue__;
  let safety = 20;
  while (vue && !vue.tableFullData && safety-- > 0) vue = vue.$parent;
  if (!vue || !vue.tableFullData) return;

  const data = vue.tableFullData;
  window.__tableFullData = data;

  if (source === 'run-vue-stats') {
    const monthly = {}, yearly = {};
    data.forEach(row => {
      const raw = row.CreateDate;
      const str = typeof raw === 'string' ? raw : raw?.toISOString?.() ?? '';
      const ym = str.slice(0, 7);
      if (ym) {
        monthly[ym] = (monthly[ym] || 0) + 1;
        const y = ym.slice(0, 4);
        yearly[y] = (yearly[y] || 0) + 1;
      }
    });
    window.postMessage({ source: 'vue-stats', monthly, yearly }, '*');
  }

  if (source === 'run-vue-export') {
    window.postMessage({ source: 'vue-export', data }, '*');
  }

  if (source === 'run-vue-export-all') {
    window.postMessage({ source: 'vue-export-all', data }, '*');
  }

  if (source === 'run-vue-panel') {
    window.postMessage({ source: 'vue-panel-data', data }, '*');
  }

  if (source === 'run-vue-print') {
    window.postMessage({ source: 'vue-print', data }, '*');
  }

  // 開發者除錯功能 - 基本欄位分析
  if (source === 'run-vue-debug-fields') {
    if (data && data.length > 0) {
      const firstRow = data[0];
      const allFields = Object.keys(firstRow);
      console.log('📋 完整欄位清單：', allFields);
      console.log('📈 總資料筆數：', data.length);
      
      allFields.forEach(field => {
        const sampleValue = firstRow[field];
        console.log(`${field}: ${sampleValue} (類型: ${typeof sampleValue})`);
      });
    } else {
      console.log('❌ 沒有資料可分析');
    }
  }

  // Payment 物件分析
  if (source === 'run-vue-payment-analysis') {
    if (data && data.length > 0) {
      console.log('💰 Payment 物件分析：');
      console.log('📊 總資料筆數：', data.length);
      
      const paymentData = data.filter(row => row.Payment && typeof row.Payment === 'object');
      console.log(`找到 ${paymentData.length} 筆 Payment 物件資料`);
      
      if (paymentData.length > 0) {
        console.log('\n💵 前5筆 Payment 資料：');
        paymentData.slice(0, 5).forEach((row, index) => {
          const totalAmount = row.Payment.TotalAmount;
          const payAmount = row.Payment.PayAmount;
          console.log(`${index + 1}. AutoID: ${row.AutoID} | TotalAmount: ${totalAmount} | PayAmount: ${payAmount}`);
        });
      } else {
        console.log('❌ 沒有找到 Payment 物件資料');
      }
    } else {
      console.log('❌ 沒有資料可分析');
    }
  }

  // WinnerID 欄位分析
  if (source === 'run-vue-winner-analysis') {
    if (data && data.length > 0) {
      console.log('🏆 WinnerID 欄位分析：');
      console.log('📊 總資料筆數：', data.length);
      
      const winnerData = data.filter(row => row.WinnerID !== null && row.WinnerID !== undefined && row.WinnerID !== '');
      console.log(`找到 ${winnerData.length} 筆有 WinnerID 的資料`);
      
      if (winnerData.length > 0) {
        console.log('\n🔍 前10筆 WinnerID 資料：');
        winnerData.slice(0, 10).forEach((row, index) => {
          const nickName = row.NickName || '';
          const account = row.Account || '';
          const winnerInfo = nickName && account ? `${nickName}(${account})` : (nickName || account || `ID: ${row.WinnerID}`);
          console.log(`${index + 1}. AutoID: ${row.AutoID} | Name: ${row.Name} | Winner: ${winnerInfo}`);
        });
        
        // 統計 WinnerID 的數值範圍
        const winnerIDs = winnerData.map(row => row.WinnerID).filter(id => !isNaN(id));
        if (winnerIDs.length > 0) {
          const minID = Math.min(...winnerIDs);
          const maxID = Math.max(...winnerIDs);
          console.log(`\n📈 WinnerID 數值範圍：${minID} - ${maxID}`);
        }
        
        // 檢查是否有重複的 WinnerID
        const uniqueWinnerIDs = [...new Set(winnerData.map(row => row.WinnerID))];
        console.log(`\n🆔 不重複的 WinnerID 數量：${uniqueWinnerIDs.length}`);
        
        if (uniqueWinnerIDs.length < winnerData.length) {
          console.log('⚠️ 發現重複的 WinnerID');
        }
        
      } else {
        console.log('❌ 沒有找到 WinnerID 資料');
      }
    } else {
      console.log('❌ 沒有資料可分析');
    }
  }
});